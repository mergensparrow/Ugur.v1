import 'package:flutter/material.dart';
import 'data/app_state.dart';
import 'data/favorites_store.dart';
import 'theme/app_theme.dart';
import 'screens/main_shell.dart';
import 'screens/welcome_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppState.instance.initialize();
  FavoritesStore.syncFromState();
  runApp(const UgurApp());
}

class UgurApp extends StatelessWidget {
  const UgurApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ugur',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      home: AppState.instance.isAuthenticated
          ? const MainShell()
          : const WelcomeScreen(),
    );
  }
}
