import 'package:flutter/material.dart';
import '../data/app_state.dart';
import '../theme/app_theme.dart';

class UiSettingsScreen extends StatelessWidget {
  const UiSettingsScreen({super.key});

  String _percent(double value) => '${(value * 100).round()}%';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text(
          'Размер интерфейса',
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
      ),
      body: AnimatedBuilder(
        animation: AppState.instance,
        builder: (_, __) {
          final state = AppState.instance;
          return ListView(
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 28),
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFFF5F8FD),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppColors.border),
                ),
                child: const Text(
                  'Здесь можно безопасно увеличить или уменьшить весь интерфейс и отдельно текст. Настройки сохраняются на устройстве.',
                  style: TextStyle(color: AppColors.muted, height: 1.45),
                ),
              ),
              const SizedBox(height: 22),
              _ScaleCard(
                title: 'Размер элементов',
                valueLabel: _percent(state.uiScale),
                value: state.uiScale,
                min: .90,
                max: 1.08,
                divisions: 18,
                onChanged: state.setUiScale,
              ),
              const SizedBox(height: 14),
              _ScaleCard(
                title: 'Размер текста',
                valueLabel: _percent(state.fontScale),
                value: state.fontScale,
                min: .90,
                max: 1.12,
                divisions: 22,
                onChanged: state.setFontScale,
              ),
              const SizedBox(height: 18),
              OutlinedButton.icon(
                onPressed: state.resetUiTuning,
                icon: const Icon(Icons.restart_alt_rounded),
                label: const Text('Вернуть 100%'),
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size.fromHeight(54),
                ),
              ),
              const SizedBox(height: 18),
              const _PreviewCard(),
            ],
          );
        },
      ),
    );
  }
}

class _ScaleCard extends StatelessWidget {
  const _ScaleCard({
    required this.title,
    required this.valueLabel,
    required this.value,
    required this.min,
    required this.max,
    required this.divisions,
    required this.onChanged,
  });

  final String title;
  final String valueLabel;
  final double value;
  final double min;
  final double max;
  final int divisions;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 15, 16, 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    color: AppColors.navy,
                    fontWeight: FontWeight.w800,
                    fontSize: 16,
                  ),
                ),
              ),
              Text(
                valueLabel,
                style: const TextStyle(
                  color: AppColors.gold,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
          Slider(
            value: value.clamp(min, max).toDouble(),
            min: min,
            max: max,
            divisions: divisions,
            label: valueLabel,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}

class _PreviewCard extends StatelessWidget {
  const _PreviewCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFFEAF4FF),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0x33D8A326)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Предпросмотр',
            style: TextStyle(
              color: AppColors.navy,
              fontSize: 22,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Так будут выглядеть основные надписи и элементы приложения.',
            style: TextStyle(color: AppColors.muted),
          ),
          const SizedBox(height: 14),
          FilledButton.icon(
            onPressed: () {},
            icon: const Icon(Icons.search_rounded),
            label: const Text('Найти гостиницы'),
          ),
        ],
      ),
    );
  }
}
