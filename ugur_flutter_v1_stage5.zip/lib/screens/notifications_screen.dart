import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key, this.showBackButton = false});

  final bool showBackButton;

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  bool onlyNew = false;
  final List<_NotificationItem> items = [
    const _NotificationItem(
      icon: Icons.check_circle,
      color: AppColors.success,
      title: 'Есть свободные номера',
      subtitle: 'Yyldyz Hotel подтвердил наличие.',
      isNew: true,
    ),
    const _NotificationItem(
      icon: Icons.schedule,
      color: AppColors.warning,
      title: 'Нужно перепроверить',
      subtitle: 'Оператор продолжает уточнение.',
      isNew: true,
    ),
    const _NotificationItem(
      icon: Icons.send,
      color: AppColors.gold,
      title: 'Запрос отправлен',
      subtitle: 'Запрос передан оператору Ugur.',
      isNew: false,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final visible = onlyNew ? items.where((item) => item.isNew).toList() : items;

    return Scaffold(
      appBar: widget.showBackButton
          ? AppBar(
              title: const Text(
                'Уведомления',
                style: TextStyle(fontWeight: FontWeight.w900),
              ),
              actions: [
                TextButton.icon(
                  onPressed: items.isEmpty ? null : () => setState(items.clear),
                  icon: const Icon(Icons.delete_outline),
                  label: const Text('Очистить'),
                ),
              ],
            )
          : null,
      body: SafeArea(
        top: !widget.showBackButton,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            if (!widget.showBackButton)
              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Уведомления',
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  TextButton.icon(
                    onPressed: items.isEmpty ? null : () => setState(items.clear),
                    icon: const Icon(Icons.delete_outline),
                    label: const Text('Очистить'),
                  ),
                ],
              ),
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: false, label: Text('Все')),
                ButtonSegment(value: true, label: Text('Новые')),
              ],
              selected: {onlyNew},
              onSelectionChanged: (value) =>
                  setState(() => onlyNew = value.first),
            ),
            const SizedBox(height: 18),
            if (visible.isEmpty)
              const Padding(
                padding: EdgeInsets.only(top: 80),
                child: Column(
                  children: [
                    Icon(
                      Icons.notifications_none_rounded,
                      size: 58,
                      color: AppColors.muted,
                    ),
                    SizedBox(height: 14),
                    Text(
                      'Уведомлений пока нет',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                  ],
                ),
              )
            else
              ...visible.map(
                (item) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Card(
                    child: ListTile(
                      leading: Icon(item.icon, color: item.color),
                      title: Text(item.title),
                      subtitle: Text(item.subtitle),
                      trailing: item.isNew
                          ? const CircleAvatar(
                              radius: 4,
                              backgroundColor: AppColors.danger,
                            )
                          : null,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _NotificationItem {
  const _NotificationItem({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.isNew,
  });

  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final bool isNew;
}
