import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'language_screen.dart';
import 'notification_settings_screen.dart';
import 'personal_profile_screen.dart';
import 'privacy_screen.dart';
import 'support_screen.dart';
import 'welcome_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  void _push(BuildContext context, Widget screen) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context) {
    Widget item(
      IconData icon,
      String title,
      VoidCallback onTap, {
      bool danger = false,
    }) =>
        ListTile(
          onTap: onTap,
          leading: Icon(
            icon,
            color: danger ? AppColors.danger : AppColors.navy,
          ),
          title: Text(
            title,
            style: TextStyle(
              fontWeight: FontWeight.w800,
              color: danger ? AppColors.danger : null,
            ),
          ),
          trailing: const Icon(Icons.chevron_right),
        );

    return SafeArea(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          Container(
            color: AppColors.navy,
            padding: const EdgeInsets.all(22),
            child: Row(
              children: [
                const CircleAvatar(
                  radius: 36,
                  backgroundColor: AppColors.gold,
                  child: Icon(Icons.person, size: 38, color: AppColors.text),
                ),
                const SizedBox(width: 14),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Мерген',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 23,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      Text('+993 •• •• ••', style: TextStyle(color: Colors.white70)),
                      Text(
                        'mergen@example.com',
                        style: TextStyle(color: Colors.white70),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  tooltip: 'Личный профиль',
                  onPressed: () =>
                      _push(context, const PersonalProfileScreen()),
                  icon: const Icon(Icons.settings_outlined, color: Colors.white),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Card(
              child: Column(
                children: [
                  item(
                    Icons.person_outline,
                    'Личный профиль',
                    () => _push(context, const PersonalProfileScreen()),
                  ),
                  item(
                    Icons.language,
                    'Язык',
                    () => _push(context, const LanguageScreen()),
                  ),
                  item(
                    Icons.notifications_none,
                    'Уведомления',
                    () => _push(context, const NotificationSettingsScreen()),
                  ),
                  item(
                    Icons.support_agent,
                    'Поддержка',
                    () => _push(context, const SupportScreen()),
                  ),
                  item(
                    Icons.privacy_tip_outlined,
                    'Конфиденциальность',
                    () => _push(context, const PrivacyScreen()),
                  ),
                  item(
                    Icons.logout,
                    'Выйти из аккаунта',
                    () => Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (_) => const WelcomeScreen()),
                      (_) => false,
                    ),
                    danger: true,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
