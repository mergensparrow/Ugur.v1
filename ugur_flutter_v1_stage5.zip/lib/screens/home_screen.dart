import 'package:flutter/material.dart';
import '../data/demo_data.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import 'city_picker_screen.dart';
import 'hotel_catalog_screen.dart';
import 'notifications_screen.dart';
import 'place_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String selectedCity = 'Ашхабад';

  static const popularCities = <_CityCardData>[
    _CityCardData(
      name: 'Аваза',
      subtitle: 'Курортная зона',
      asset: 'assets/images/city_avaza.jpg',
    ),
    _CityCardData(
      name: 'Туркменбаши',
      subtitle: 'Портовый город',
      asset: 'assets/images/city_turkmenbashi.jpg',
    ),
    _CityCardData(
      name: 'Дашогуз',
      subtitle: 'Исторический город',
      asset: 'assets/images/city_dashoguz.jpg',
    ),
  ];

  static const otherCities = <_SmallCityData>[
    _SmallCityData('Балканабат', Color(0xFFFFF1D7), Color(0xFFD6921D)),
    _SmallCityData('Мары', Color(0xFFF0E9FF), Color(0xFF7652C6)),
    _SmallCityData('Туркменабад', Color(0xFFE9F8EE), Color(0xFF2E9A58)),
    _SmallCityData('Дашогуз', Color(0xFFE7F4FF), Color(0xFF2788CA)),
  ];

  Future<void> _pickCity() async {
    final value = await Navigator.of(context).push<String>(
      MaterialPageRoute(
        builder: (_) => CityPickerScreen(initialCity: selectedCity),
      ),
    );
    if (value != null && mounted) {
      setState(() => selectedCity = value);
    }
  }

  void _openCatalog([String? city]) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => HotelCatalogScreen(city: city ?? selectedCity),
      ),
    );
  }

  void _openNotifications() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const NotificationsScreen(showBackButton: true)),
    );
  }

  void _openPlace(TouristPlace place) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => PlaceDetailScreen(place: place)),
    );
  }

  void _showAllPlaces() {
    final places = placesForCity(selectedCity);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                popularPlacesTitle(selectedCity),
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 12),
              ...places.map(
                (place) => Card(
                  child: ListTile(
                    onTap: () {
                      Navigator.pop(sheetContext);
                      _openPlace(place);
                    },
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.asset(
                        place.image,
                        width: 58,
                        height: 58,
                        fit: BoxFit.cover,
                      ),
                    ),
                    title: Text(
                      place.name,
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: Text(place.category),
                    trailing: const Icon(Icons.chevron_right_rounded),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final places = placesForCity(selectedCity);

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 28),
        children: [
          _TopBrand(onNotifications: _openNotifications),
          const SizedBox(height: 24),
          _CityDiscoveryPanel(
            selectedCity: selectedCity,
            places: places,
            onPickCity: _pickCity,
            onOpenPlace: _openPlace,
            onShowAllPlaces: _showAllPlaces,
            onSearchHotels: _openCatalog,
          ),
          const SizedBox(height: 16),
          _CountryDiscoveryPanel(
            popularCities: popularCities,
            otherCities: otherCities,
            onOpenCity: _openCatalog,
          ),
        ],
      ),
    );
  }
}

class _TopBrand extends StatelessWidget {
  const _TopBrand({required this.onNotifications});

  final VoidCallback onNotifications;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(
          width: 48,
          height: 48,
          child: Icon(Icons.route_rounded, color: AppColors.gold, size: 43),
        ),
        const SizedBox(width: 6),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'ugur',
                style: TextStyle(
                  fontSize: 31,
                  height: 1,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -1,
                ),
              ),
              SizedBox(height: 5),
              Text(
                'ГОСТИНИЦЫ ТУРКМЕНИСТАНА',
                style: TextStyle(
                  fontSize: 9,
                  letterSpacing: .55,
                  color: AppColors.muted,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
        Badge(
          label: const Text('2'),
          child: IconButton(
            tooltip: 'Уведомления',
            onPressed: onNotifications,
            icon: const Icon(Icons.notifications_none_rounded, size: 30),
          ),
        ),
      ],
    );
  }
}

class _CityDiscoveryPanel extends StatelessWidget {
  const _CityDiscoveryPanel({
    required this.selectedCity,
    required this.places,
    required this.onPickCity,
    required this.onOpenPlace,
    required this.onShowAllPlaces,
    required this.onSearchHotels,
  });

  final String selectedCity;
  final List<TouristPlace> places;
  final VoidCallback onPickCity;
  final ValueChanged<TouristPlace> onOpenPlace;
  final VoidCallback onShowAllPlaces;
  final VoidCallback onSearchHotels;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 26, 16, 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: const Color(0x28D7A846)),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFFFFAF1), Color(0xFFF2F7FF)],
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x10000000),
            blurRadius: 24,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Куда вы хотите\nпоехать?',
            style: TextStyle(
              fontSize: 34,
              height: 1.02,
              fontWeight: FontWeight.w900,
              letterSpacing: -1.1,
              color: AppColors.text,
            ),
          ),
          const SizedBox(height: 13),
          const Text(
            'Выберите город, чтобы увидеть лучшие\nварианты проживания',
            style: TextStyle(
              color: AppColors.muted,
              fontSize: 14,
              height: 1.4,
            ),
          ),
          const SizedBox(height: 24),
          Material(
            color: Colors.white,
            borderRadius: BorderRadius.circular(23),
            child: InkWell(
              onTap: onPickCity,
              borderRadius: BorderRadius.circular(23),
              child: Container(
                padding: const EdgeInsets.fromLTRB(15, 14, 14, 14),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(23),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x0D000000),
                      blurRadius: 22,
                      offset: Offset(0, 9),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      width: 46,
                      height: 46,
                      decoration: const BoxDecoration(
                        color: Color(0xFFFFF4D7),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.location_on_rounded,
                        color: AppColors.gold,
                        size: 28,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Выбранный город',
                            style: TextStyle(
                              color: AppColors.gold,
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            selectedCity,
                            style: const TextStyle(
                              fontSize: 21,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.keyboard_arrow_down_rounded, size: 28),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 25),
          Row(
            children: [
              Expanded(
                child: Text(
                  popularPlacesTitle(selectedCity),
                  maxLines: 2,
                  style: const TextStyle(
                    fontSize: 18,
                    height: 1.1,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              TextButton(
                onPressed: onShowAllPlaces,
                child: const Text('Смотреть все'),
              ),
            ],
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 205,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: places.length,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (_, index) {
                final place = places[index];
                return _PlaceCard(
                  place: place,
                  onTap: () => onOpenPlace(place),
                );
              },
            ),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: onSearchHotels,
            icon: const Icon(Icons.search_rounded),
            label: const Text('Найти гостиницы'),
          ),
        ],
      ),
    );
  }
}

class _PlaceCard extends StatelessWidget {
  const _PlaceCard({required this.place, required this.onTap});

  final TouristPlace place;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: SizedBox(
          width: 132,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: Stack(
              fit: StackFit.expand,
              children: [
                Image.asset(place.image, fit: BoxFit.cover),
                const DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.transparent, Color(0xDD031322)],
                    ),
                  ),
                ),
                Positioned(
                  left: 10,
                  right: 9,
                  bottom: 11,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        place.name,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          height: 1.1,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Row(
                        children: [
                          const Icon(
                            Icons.location_on_rounded,
                            color: AppColors.gold,
                            size: 13,
                          ),
                          const SizedBox(width: 3),
                          Expanded(
                            child: Text(
                              place.category,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 9.5,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _CountryDiscoveryPanel extends StatelessWidget {
  const _CountryDiscoveryPanel({
    required this.popularCities,
    required this.otherCities,
    required this.onOpenCity,
  });

  final List<_CityCardData> popularCities;
  final List<_SmallCityData> otherCities;
  final ValueChanged<String> onOpenCity;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 18, 14, 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: const Color(0x11000000)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0D000000),
            blurRadius: 20,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Популярные направления',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 145,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: popularCities.length,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (_, index) {
                final city = popularCities[index];
                return _DestinationCard(
                  data: city,
                  onTap: () => onOpenCity(city.name),
                );
              },
            ),
          ),
          const SizedBox(height: 19),
          const Divider(height: 1),
          const SizedBox(height: 18),
          const Text(
            'Другие города',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 122,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: otherCities.length,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (_, index) {
                final city = otherCities[index];
                return _OtherCityCard(
                  data: city,
                  onTap: () => onOpenCity(city.name),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _DestinationCard extends StatelessWidget {
  const _DestinationCard({required this.data, required this.onTap});

  final _CityCardData data;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: SizedBox(
        width: 230,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(19),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.asset(data.asset, fit: BoxFit.cover),
              const DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Color(0xD9000000)],
                  ),
                ),
              ),
              Positioned(
                left: 14,
                right: 12,
                bottom: 12,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      data.name,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    Text(
                      data.subtitle,
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _OtherCityCard extends StatelessWidget {
  const _OtherCityCard({required this.data, required this.onTap});

  final _SmallCityData data;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xFFFCFCFD),
      borderRadius: BorderRadius.circular(19),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(19),
        child: Container(
          width: 112,
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(19),
            border: Border.all(color: const Color(0x0F000000)),
          ),
          child: Column(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: data.iconBackground,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.apartment_rounded,
                  color: data.iconColor,
                  size: 22,
                ),
              ),
              const Spacer(),
              Text(
                data.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontWeight: FontWeight.w900,
                  fontSize: 12,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                '${cityHotelCounts[data.name] ?? 0} гостиниц',
                style: const TextStyle(color: AppColors.muted, fontSize: 9),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CityCardData {
  const _CityCardData({
    required this.name,
    required this.subtitle,
    required this.asset,
  });

  final String name;
  final String subtitle;
  final String asset;
}

class _SmallCityData {
  const _SmallCityData(this.name, this.iconBackground, this.iconColor);

  final String name;
  final Color iconBackground;
  final Color iconColor;
}
