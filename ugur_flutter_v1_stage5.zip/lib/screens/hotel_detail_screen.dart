import 'package:flutter/material.dart';
import '../data/favorites_store.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import 'availability_request_screen.dart';
import 'room_prices_screen.dart';

class HotelDetailScreen extends StatefulWidget {
  const HotelDetailScreen({
    super.key,
    required this.hotel,
    this.initialTab = 0,
  });

  final Hotel hotel;
  final int initialTab;

  @override
  State<HotelDetailScreen> createState() => _HotelDetailScreenState();
}

class _HotelDetailScreenState extends State<HotelDetailScreen> {
  static const tabLabels = ['Об отеле', 'Отзывы', 'Удобства'];

  final ScrollController _scrollController = ScrollController();
  final GlobalKey _tabsKey = GlobalKey();
  late int selectedTab;

  Hotel get hotel => widget.hotel;

  @override
  void initState() {
    super.initState();
    selectedTab = widget.initialTab.clamp(0, tabLabels.length - 1).toInt();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _selectTab(int index, {bool scrollToTabs = false}) {
    setState(() => selectedTab = index);
    if (scrollToTabs) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        final context = _tabsKey.currentContext;
        if (context != null) {
          Scrollable.ensureVisible(
            context,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOut,
            alignment: .08,
          );
        }
      });
    }
  }

  void _share() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Ссылка на ${hotel.name} подготовлена.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bottomPadding = 36 + MediaQuery.paddingOf(context).bottom;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        controller: _scrollController,
        slivers: [
          SliverAppBar(
            pinned: true,
            stretch: true,
            expandedHeight: 340,
            backgroundColor: Colors.white,
            foregroundColor: AppColors.text,
            title: Text(
              hotel.name,
              style: const TextStyle(fontWeight: FontWeight.w900),
            ),
            actions: [
              IconButton.filledTonal(
                tooltip: 'Поделиться',
                onPressed: _share,
                icon: const Icon(Icons.share_outlined),
              ),
              ValueListenableBuilder<Set<String>>(
                valueListenable: FavoritesStore.hotels,
                builder: (_, favorites, __) {
                  final favorite = favorites.contains(hotel.name);
                  return IconButton.filledTonal(
                    tooltip: 'Избранное',
                    onPressed: () => FavoritesStore.toggle(hotel.name),
                    icon: Icon(
                      favorite
                          ? Icons.favorite_rounded
                          : Icons.favorite_border_rounded,
                      color: favorite ? AppColors.danger : null,
                    ),
                  );
                },
              ),
              const SizedBox(width: 8),
            ],
            flexibleSpace: FlexibleSpaceBar(
              stretchModes: const [StretchMode.zoomBackground],
              background: Stack(
                fit: StackFit.expand,
                children: [
                  Image.asset(
                    hotel.image,
                    fit: BoxFit.cover,
                    filterQuality: FilterQuality.high,
                  ),
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Color(0x20000000),
                          Colors.transparent,
                          Color(0x66000000),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    left: 18,
                    bottom: 15,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 11,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xB5000000),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Text(
                        '1 / 24',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.fromLTRB(18, 20, 18, bottomPadding),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              hotel.name,
                              style: const TextStyle(
                                fontSize: 29,
                                fontWeight: FontWeight.w900,
                                letterSpacing: -.8,
                              ),
                            ),
                            const SizedBox(height: 5),
                            Text(
                              hotel.city,
                              style: const TextStyle(
                                color: AppColors.muted,
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Row(
                            children: [
                              const Icon(
                                Icons.star_rounded,
                                color: AppColors.gold,
                                size: 23,
                              ),
                              Text(
                                ' ${hotel.rating}',
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                            ],
                          ),
                          Text(
                            '${hotel.reviews} отзывов',
                            style: const TextStyle(
                              color: AppColors.muted,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  _AvailabilityLine(status: hotel.status),
                  const SizedBox(height: 16),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(
                        Icons.location_on_outlined,
                        color: AppColors.muted,
                        size: 19,
                      ),
                      const SizedBox(width: 7),
                      Expanded(
                        child: Text(
                          hotel.address,
                          style: const TextStyle(
                            color: AppColors.muted,
                            fontSize: 13,
                            height: 1.35,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  _AmenitiesStrip(amenities: hotel.amenities, compact: true),
                  const SizedBox(height: 22),
                  Text(
                    'от ${hotel.price} TMT / ночь',
                    style: const TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 5),
                  const Text(
                    'Цена за стандартный номер',
                    style: TextStyle(color: AppColors.muted, fontSize: 12),
                  ),
                  const SizedBox(height: 24),
                  KeyedSubtree(
                    key: _tabsKey,
                    child: _HotelTabs(
                      labels: tabLabels,
                      selected: selectedTab,
                      onSelected: _selectTab,
                    ),
                  ),
                  const SizedBox(height: 18),
                  _tabContent(selectedTab),
                  const SizedBox(height: 28),
                  FilledButton.icon(
                    onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => RoomPricesScreen(hotel: hotel),
                      ),
                    ),
                    icon: const Icon(Icons.payments_outlined),
                    label: const Text('Цены на номера'),
                    style: FilledButton.styleFrom(
                      backgroundColor: AppColors.gold,
                      foregroundColor: AppColors.text,
                    ),
                  ),
                  const SizedBox(height: 10),
                  FilledButton.icon(
                    onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) =>
                            AvailabilityRequestScreen(hotel: hotel),
                      ),
                    ),
                    icon: const Icon(Icons.search_rounded),
                    label: const Text('Проверить наличие'),
                  ),
                  const SizedBox(height: 10),
                  FilledButton.icon(
                    onPressed: null,
                    icon: const Icon(Icons.lock_clock_outlined),
                    label: const Text(
                      'Онлайн-бронирование · Скоро в Ugur',
                    ),
                    style: FilledButton.styleFrom(
                      disabledBackgroundColor: AppColors.text,
                      disabledForegroundColor: Colors.white70,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _tabContent(int index) {
    return switch (index) {
      0 => _AboutTab(
          hotel: hotel,
          onShowReviews: () => _selectTab(1, scrollToTabs: true),
        ),
      1 => const _ReviewsTab(),
      _ => _AmenitiesTab(amenities: hotel.amenities),
    };
  }
}

class _HotelTabs extends StatelessWidget {
  const _HotelTabs({
    required this.labels,
    required this.selected,
    required this.onSelected,
  });

  final List<String> labels;
  final int selected;
  final ValueChanged<int> onSelected;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: List.generate(labels.length, (index) {
        final active = selected == index;
        return Expanded(
          child: Padding(
            padding: EdgeInsets.only(
              right: index == labels.length - 1 ? 0 : 7,
            ),
            child: Material(
              color: active ? AppColors.text : Colors.white,
              borderRadius: BorderRadius.circular(15),
              child: InkWell(
                onTap: () => onSelected(index),
                borderRadius: BorderRadius.circular(15),
                child: Container(
                  height: 46,
                  alignment: Alignment.center,
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: const Color(0x10000000)),
                  ),
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(
                      labels[index],
                      style: TextStyle(
                        color: active ? Colors.white : AppColors.text,
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      }),
    );
  }
}

class _AboutTab extends StatelessWidget {
  const _AboutTab({required this.hotel, required this.onShowReviews});

  final Hotel hotel;
  final VoidCallback onShowReviews;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(17),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Описание отеля',
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 11),
                Text(
                  '${hotel.name} — гостиничный комплекс в городе ${hotel.city}. ${hotel.description} Комфортные номера, сервис и удобное расположение подходят как для отдыха, так и для деловых поездок.',
                  style: const TextStyle(fontSize: 14, height: 1.55),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        const Text(
          'Удобства',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 11),
        Card(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 17),
            child: _AmenitiesStrip(amenities: hotel.amenities),
          ),
        ),
        const SizedBox(height: 22),
        Row(
          children: [
            const Expanded(
              child: Text(
                'Отзывы гостей',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
              ),
            ),
            TextButton(
              onPressed: onShowReviews,
              child: const Text('Все отзывы ›'),
            ),
          ],
        ),
        const SizedBox(height: 9),
        const _ReviewCard(),
      ],
    );
  }
}

class _ReviewsTab extends StatelessWidget {
  const _ReviewsTab();

  @override
  Widget build(BuildContext context) {
    return const Column(
      children: [
        _ReviewCard(),
        SizedBox(height: 12),
        _ReviewCard(
          name: 'Мяхри А.',
          date: '8 апреля 2026',
          rating: 4,
          text:
              'Красивый интерьер, чисто и спокойно. Персонал быстро помог с вопросами. Номер был подготовлен вовремя, все основные удобства работали.',
        ),
        SizedBox(height: 12),
        _ReviewCard(
          name: 'Бегенч М.',
          date: '19 марта 2026',
          rating: 5,
          text:
              'Удобное расположение и внимательный персонал. Понравилась чистота в номере и спокойная атмосфера. Вернулся бы ещё раз.',
        ),
        SizedBox(height: 12),
        _ReviewCard(
          name: 'Анна К.',
          date: '3 февраля 2026',
          rating: 4,
          text:
              'Хороший вариант для короткой поездки. Заселение прошло быстро, сотрудники подробно ответили на вопросы.',
        ),
      ],
    );
  }
}

class _AmenitiesTab extends StatelessWidget {
  const _AmenitiesTab({required this.amenities});

  final List<String> amenities;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 20),
        child: _AmenitiesStrip(amenities: amenities),
      ),
    );
  }
}

class _AmenitiesStrip extends StatelessWidget {
  const _AmenitiesStrip({required this.amenities, this.compact = false});

  final List<String> amenities;
  final bool compact;

  static const iconByAmenity = <String, IconData>{
    'Wi‑Fi': Icons.wifi_rounded,
    'Парковка': Icons.local_parking_outlined,
    'Бассейн': Icons.pool_outlined,
    'Ресторан': Icons.restaurant_outlined,
    'Кондиционер': Icons.ac_unit_rounded,
    'Завтрак': Icons.free_breakfast_outlined,
  };

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: compact ? 70 : 82,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: amenities.length,
        separatorBuilder: (_, __) => SizedBox(width: compact ? 18 : 21),
        itemBuilder: (_, index) {
          final label = amenities[index];
          final icon = iconByAmenity[label] ?? Icons.check_circle_outline_rounded;
          return SizedBox(
            width: compact ? 58 : 68,
            child: Column(
              children: [
                Container(
                  width: compact ? 42 : 47,
                  height: compact ? 42 : 47,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(color: Color(0x10000000), blurRadius: 11),
                    ],
                  ),
                  child: Icon(icon, size: compact ? 21 : 23),
                ),
                const SizedBox(height: 6),
                Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: compact ? 9 : 10),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _AvailabilityLine extends StatelessWidget {
  const _AvailabilityLine({required this.status});

  final AvailabilityStatus status;

  Color get color => switch (status) {
        AvailabilityStatus.available => AppColors.success,
        AvailabilityStatus.unavailable => AppColors.danger,
        AvailabilityStatus.recheck => AppColors.warning,
        AvailabilityStatus.checking => AppColors.gold,
      };

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        CircleAvatar(radius: 5, backgroundColor: color),
        const SizedBox(width: 8),
        Text(
          status.label,
          style: TextStyle(color: color, fontWeight: FontWeight.w900),
        ),
      ],
    );
  }
}

class _ReviewCard extends StatelessWidget {
  const _ReviewCard({
    this.name = 'Алексей Петров',
    this.date = '12 мая 2024',
    this.rating = 5,
    this.text =
        'Отличный отель! Чисто, уютно, прекрасный персонал. Обязательно вернусь снова.',
  });

  final String name;
  final String date;
  final int rating;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const CircleAvatar(
                  backgroundColor: Color(0xFFE9ECF0),
                  child: Icon(Icons.person_rounded),
                ),
                const SizedBox(width: 11),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        style: const TextStyle(fontWeight: FontWeight.w900),
                      ),
                      Text(
                        date,
                        style: const TextStyle(
                          color: AppColors.muted,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.star_rounded, color: AppColors.gold),
                Text(
                  '$rating.0',
                  style: const TextStyle(fontWeight: FontWeight.w900),
                ),
              ],
            ),
            const SizedBox(height: 13),
            Text(text, style: const TextStyle(height: 1.45)),
          ],
        ),
      ),
    );
  }
}
