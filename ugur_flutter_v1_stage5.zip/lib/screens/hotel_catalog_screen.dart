import 'package:flutter/material.dart';
import '../data/demo_data.dart';
import '../data/favorites_store.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import 'hotel_detail_screen.dart';
import 'notifications_screen.dart';

class HotelCatalogScreen extends StatefulWidget {
  const HotelCatalogScreen({super.key, required this.city});

  final String city;

  @override
  State<HotelCatalogScreen> createState() => _HotelCatalogScreenState();
}

class _HotelCatalogScreenState extends State<HotelCatalogScreen> {
  String? activeSort;
  RangeValues priceRange = const RangeValues(0, 3000);
  double minRating = 0;
  bool onlyAvailable = false;
  Set<String> selectedAmenities = <String>{};

  static const allAmenities = [
    'Wi‑Fi',
    'Парковка',
    'Бассейн',
    'Ресторан',
    'Кондиционер',
    'Завтрак',
  ];

  bool get filtersApplied =>
      priceRange.start > 0 ||
      priceRange.end < 3000 ||
      minRating > 0 ||
      onlyAvailable ||
      selectedAmenities.isNotEmpty;

  List<Hotel> get cityHotels {
    final result = hotelsForCity(widget.city).where((hotel) {
      final priceMatches =
          hotel.price >= priceRange.start && hotel.price <= priceRange.end;
      final ratingMatches = hotel.rating >= minRating;
      final availabilityMatches =
          !onlyAvailable || hotel.status == AvailabilityStatus.available;
      final amenitiesMatch = selectedAmenities.every(hotel.amenities.contains);
      return priceMatches &&
          ratingMatches &&
          availabilityMatches &&
          amenitiesMatch;
    }).toList();

    if (activeSort == 'Цена') {
      result.sort((a, b) => a.price.compareTo(b.price));
    } else if (activeSort == 'Рейтинг') {
      result.sort((a, b) => b.rating.compareTo(a.rating));
    } else if (activeSort == 'Наличие') {
      result.sort(
        (a, b) =>
            _availabilityOrder(a.status).compareTo(_availabilityOrder(b.status)),
      );
    }
    return result;
  }

  int _availabilityOrder(AvailabilityStatus status) => switch (status) {
        AvailabilityStatus.available => 0,
        AvailabilityStatus.checking => 1,
        AvailabilityStatus.recheck => 2,
        AvailabilityStatus.unavailable => 3,
      };

  void _toggleSort(String value) {
    setState(() => activeSort = activeSort == value ? null : value);
  }

  void _openHotel(Hotel hotel, {bool reviews = false}) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => HotelDetailScreen(
          hotel: hotel,
          initialTab: reviews ? 1 : 0,
        ),
      ),
    );
  }

  void _openNotifications() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const NotificationsScreen(showBackButton: true)),
    );
  }

  Future<void> _openFilters() async {
    var draftPrice = priceRange;
    var draftRating = minRating;
    var draftOnlyAvailable = onlyAvailable;
    var draftAmenities = Set<String>.from(selectedAmenities);

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return SafeArea(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 22),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Фильтры гостиниц',
                      style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        const Expanded(
                          child: Text(
                            'Цена за ночь',
                            style: TextStyle(fontWeight: FontWeight.w900),
                          ),
                        ),
                        Text(
                          '${draftPrice.start.round()}–${draftPrice.end.round()} TMT',
                          style: const TextStyle(
                            color: AppColors.gold,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ],
                    ),
                    RangeSlider(
                      min: 0,
                      max: 3000,
                      divisions: 30,
                      values: draftPrice,
                      labels: RangeLabels(
                        '${draftPrice.start.round()} TMT',
                        '${draftPrice.end.round()} TMT',
                      ),
                      onChanged: (value) =>
                          setSheetState(() => draftPrice = value),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Минимальный рейтинг',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [0.0, 3.0, 4.0, 4.5].map((rating) {
                        final selected = draftRating == rating;
                        return ChoiceChip(
                          selected: selected,
                          label: Text(rating == 0 ? 'Любой' : '$rating+'),
                          onSelected: (_) =>
                              setSheetState(() => draftRating = rating),
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 16),
                    SwitchListTile.adaptive(
                      contentPadding: EdgeInsets.zero,
                      value: draftOnlyAvailable,
                      title: const Text(
                        'Только с доступными номерами',
                        style: TextStyle(fontWeight: FontWeight.w900),
                      ),
                      onChanged: (value) => setSheetState(
                        () => draftOnlyAvailable = value,
                      ),
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      'Удобства',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: allAmenities.map((amenity) {
                        final selected = draftAmenities.contains(amenity);
                        return FilterChip(
                          selected: selected,
                          label: Text(amenity),
                          onSelected: (value) {
                            setSheetState(() {
                              if (value) {
                                draftAmenities.add(amenity);
                              } else {
                                draftAmenities.remove(amenity);
                              }
                            });
                          },
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 24),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () {
                              setSheetState(() {
                                draftPrice = const RangeValues(0, 3000);
                                draftRating = 0;
                                draftOnlyAvailable = false;
                                draftAmenities = <String>{};
                              });
                            },
                            child: const Text('Сбросить'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: FilledButton(
                            onPressed: () {
                              setState(() {
                                priceRange = draftPrice;
                                minRating = draftRating;
                                onlyAvailable = draftOnlyAvailable;
                                selectedAmenities = draftAmenities;
                              });
                              Navigator.pop(sheetContext);
                            },
                            child: const Text('Применить'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final list = cityHotels;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        toolbarHeight: 74,
        titleSpacing: 20,
        automaticallyImplyLeading: false,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.city,
              style: const TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w900,
                letterSpacing: -.7,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              '${list.length} гостиниц найдено',
              style: const TextStyle(fontSize: 13, color: AppColors.muted),
            ),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Badge(
              label: const Text('2'),
              child: IconButton(
                tooltip: 'Уведомления',
                onPressed: _openNotifications,
                icon: const Icon(Icons.notifications_none_rounded, size: 29),
              ),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 8, 14, 8),
            child: Row(
              children: [
                Expanded(
                  child: _FilterPill(
                    icon: Icons.savings_outlined,
                    label: 'Цена',
                    selected: activeSort == 'Цена',
                    onTap: () => _toggleSort('Цена'),
                  ),
                ),
                const SizedBox(width: 7),
                Expanded(
                  child: _FilterPill(
                    icon: Icons.star_rounded,
                    label: 'Рейтинг',
                    selected: activeSort == 'Рейтинг',
                    onTap: () => _toggleSort('Рейтинг'),
                  ),
                ),
                const SizedBox(width: 7),
                Expanded(
                  child: _FilterPill(
                    icon: Icons.bed_outlined,
                    label: 'Наличие',
                    selected: activeSort == 'Наличие',
                    onTap: () => _toggleSort('Наличие'),
                  ),
                ),
                const SizedBox(width: 7),
                Expanded(
                  child: _FilterPill(
                    icon: Icons.tune_rounded,
                    label: 'Фильтры',
                    selected: filtersApplied,
                    onTap: _openFilters,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: list.isEmpty
                ? _EmptyCatalog(
                    city: widget.city,
                    filtersApplied: filtersApplied,
                    onReset: () => setState(() {
                      priceRange = const RangeValues(0, 3000);
                      minRating = 0;
                      onlyAvailable = false;
                      selectedAmenities = <String>{};
                    }),
                  )
                : ValueListenableBuilder<Set<String>>(
                    valueListenable: FavoritesStore.hotels,
                    builder: (_, favorites, __) {
                      return ListView.separated(
                        padding: const EdgeInsets.fromLTRB(18, 8, 18, 26),
                        itemCount: list.length,
                        separatorBuilder: (_, __) =>
                            const SizedBox(height: 14),
                        itemBuilder: (_, index) {
                          final hotel = list[index];
                          if (index == 0) {
                            return _FeaturedHotelCard(
                              hotel: hotel,
                              isFavorite: favorites.contains(hotel.name),
                              onFavorite: () =>
                                  FavoritesStore.toggle(hotel.name),
                              onTap: () => _openHotel(hotel),
                              onReviews: () =>
                                  _openHotel(hotel, reviews: true),
                            );
                          }
                          return _CompactHotelCard(
                            hotel: hotel,
                            isFavorite: favorites.contains(hotel.name),
                            onFavorite: () =>
                                FavoritesStore.toggle(hotel.name),
                            onTap: () => _openHotel(hotel),
                            onReviews: () => _openHotel(hotel, reviews: true),
                          );
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _EmptyCatalog extends StatelessWidget {
  const _EmptyCatalog({
    required this.city,
    required this.filtersApplied,
    required this.onReset,
  });

  final String city;
  final bool filtersApplied;
  final VoidCallback onReset;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.hotel_outlined, size: 60, color: AppColors.muted),
            const SizedBox(height: 15),
            Text(
              filtersApplied
                  ? 'По выбранным фильтрам ничего не найдено'
                  : 'В городе $city пока нет добавленных гостиниц',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
            ),
            if (filtersApplied) ...[
              const SizedBox(height: 16),
              OutlinedButton(
                onPressed: onReset,
                child: const Text('Сбросить фильтры'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _FilterPill extends StatelessWidget {
  const _FilterPill({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: selected ? const Color(0xFFFFF4D7) : Colors.white,
      borderRadius: BorderRadius.circular(17),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(17),
        child: Container(
          height: 48,
          padding: const EdgeInsets.symmetric(horizontal: 5),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(17),
            boxShadow: const [
              BoxShadow(
                color: Color(0x0D000000),
                blurRadius: 12,
                offset: Offset(0, 5),
              ),
            ],
          ),
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  icon,
                  color: selected ? AppColors.gold : AppColors.text,
                  size: 18,
                ),
                const SizedBox(width: 4),
                Text(
                  label,
                  style: const TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _FeaturedHotelCard extends StatelessWidget {
  const _FeaturedHotelCard({
    required this.hotel,
    required this.isFavorite,
    required this.onFavorite,
    required this.onTap,
    required this.onReviews,
  });

  final Hotel hotel;
  final bool isFavorite;
  final VoidCallback onFavorite;
  final VoidCallback onTap;
  final VoidCallback onReviews;

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                Image.asset(
                  hotel.image,
                  width: double.infinity,
                  height: 176,
                  fit: BoxFit.cover,
                  filterQuality: FilterQuality.medium,
                ),
                Positioned(
                  top: 13,
                  right: 13,
                  child: _FavoriteButton(
                    isFavorite: isFavorite,
                    onPressed: onFavorite,
                    darkBackground: true,
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(17, 14, 17, 0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          hotel.name,
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w900,
                            letterSpacing: -.4,
                          ),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          hotel.city,
                          style: const TextStyle(
                            color: AppColors.muted,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),
                  _StatusBadge(status: hotel.status),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(17, 13, 17, 14),
              child: Row(
                children: [
                  const Icon(Icons.star_rounded, color: AppColors.gold, size: 24),
                  Text(
                    ' ${hotel.rating}',
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const Spacer(),
                  Flexible(
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerRight,
                      child: Text(
                        'от ${hotel.price} TMT / ночь',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const Divider(height: 1),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              child: Row(
                children: [
                  const SizedBox(width: 5),
                  const Icon(Icons.star_border_rounded, size: 22),
                  Text(
                    ' ${hotel.rating}',
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(width: 9),
                  InkWell(
                    onTap: onReviews,
                    borderRadius: BorderRadius.circular(12),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 7,
                        vertical: 8,
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.chat_bubble_outline_rounded, size: 20),
                          Text(
                            ' ${hotel.reviews}',
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    onPressed: onFavorite,
                    icon: Icon(
                      isFavorite
                          ? Icons.bookmark_rounded
                          : Icons.bookmark_border_rounded,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CompactHotelCard extends StatelessWidget {
  const _CompactHotelCard({
    required this.hotel,
    required this.isFavorite,
    required this.onFavorite,
    required this.onTap,
    required this.onReviews,
  });

  final Hotel hotel;
  final bool isFavorite;
  final VoidCallback onFavorite;
  final VoidCallback onTap;
  final VoidCallback onReviews;

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: SizedBox(
          height: 210,
          child: Row(
            children: [
              SizedBox(
                width: 142,
                height: double.infinity,
                child: Image.asset(
                  hotel.image,
                  fit: BoxFit.cover,
                  filterQuality: FilterQuality.medium,
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 10, 8, 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Text(
                              hotel.name,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 18,
                                height: 1.05,
                                fontWeight: FontWeight.w900,
                                letterSpacing: -.3,
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 34,
                            height: 34,
                            child: _FavoriteButton(
                              isFavorite: isFavorite,
                              onPressed: onFavorite,
                            ),
                          ),
                        ],
                      ),
                      if (hotel.status != AvailabilityStatus.available) ...[
                        const SizedBox(height: 4),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: _StatusBadge(status: hotel.status),
                        ),
                      ],
                      const SizedBox(height: 5),
                      Text(
                        hotel.city,
                        style: const TextStyle(
                          color: AppColors.muted,
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          const Icon(
                            Icons.star_rounded,
                            color: AppColors.gold,
                            size: 18,
                          ),
                          Text(
                            ' ${hotel.rating}',
                            style: const TextStyle(
                              fontWeight: FontWeight.w900,
                              fontSize: 13,
                            ),
                          ),
                          Expanded(
                            child: Text(
                              ' (${hotel.reviews} отзывов)',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: AppColors.muted,
                                fontSize: 10,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      FittedBox(
                        fit: BoxFit.scaleDown,
                        alignment: Alignment.centerLeft,
                        child: Text(
                          'от ${hotel.price} TMT',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                      const Text(
                        '/ ночь',
                        style: TextStyle(color: AppColors.muted, fontSize: 10),
                      ),
                      const Spacer(),
                      Container(height: 1, color: const Color(0x12000000)),
                      SizedBox(
                        height: 35,
                        child: Row(
                          children: [
                            const Icon(Icons.star_border_rounded, size: 18),
                            Text(
                              ' ${hotel.rating}',
                              style: const TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 11,
                              ),
                            ),
                            const SizedBox(width: 5),
                            InkWell(
                              onTap: onReviews,
                              borderRadius: BorderRadius.circular(10),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 5,
                                  vertical: 7,
                                ),
                                child: Row(
                                  children: [
                                    const Icon(
                                      Icons.chat_bubble_outline_rounded,
                                      size: 16,
                                    ),
                                    Text(
                                      ' ${hotel.reviews}',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontSize: 11,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            const Spacer(),
                            Icon(
                              isFavorite
                                  ? Icons.bookmark_rounded
                                  : Icons.bookmark_border_rounded,
                              size: 20,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FavoriteButton extends StatelessWidget {
  const _FavoriteButton({
    required this.isFavorite,
    required this.onPressed,
    this.darkBackground = false,
  });

  final bool isFavorite;
  final VoidCallback onPressed;
  final bool darkBackground;

  @override
  Widget build(BuildContext context) {
    return IconButton(
      onPressed: onPressed,
      visualDensity: VisualDensity.compact,
      style: IconButton.styleFrom(
        backgroundColor: darkBackground ? const Color(0x99000000) : Colors.transparent,
        foregroundColor: darkBackground
            ? Colors.white
            : (isFavorite ? AppColors.danger : AppColors.text),
      ),
      icon: Icon(
        isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  const _StatusBadge({required this.status});

  final AvailabilityStatus status;

  Color get color => switch (status) {
        AvailabilityStatus.available => AppColors.success,
        AvailabilityStatus.unavailable => AppColors.danger,
        AvailabilityStatus.recheck => AppColors.warning,
        AvailabilityStatus.checking => AppColors.gold,
      };

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
        color: color.withAlpha(36),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(
        status.label,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          color: color,
          fontSize: 10.5,
          fontWeight: FontWeight.w900,
        ),
      ),
    );
  }
}
