from pathlib import Path
import re
import sys

root = Path(__file__).resolve().parents[1]
required = [
    "pubspec.yaml",
    "lib/main.dart",
    "lib/screens/welcome_screen.dart",
    "lib/screens/login_screen.dart",
    "lib/screens/register_screen.dart",
    "lib/screens/reviews_screen.dart",
    "lib/data/app_state.dart",
    "lib/screens/home_screen.dart",
    "lib/screens/city_picker_screen.dart",
    "lib/screens/place_detail_screen.dart",
    "lib/screens/hotel_catalog_screen.dart",
    "lib/screens/hotel_detail_screen.dart",
    "lib/screens/room_prices_screen.dart",
    "lib/screens/availability_request_screen.dart",
    "lib/screens/favorites_screen.dart",
    "lib/screens/notifications_screen.dart",
    "lib/screens/profile_screen.dart",
    "lib/screens/personal_profile_screen.dart",
    "lib/screens/edit_profile_screen.dart",
    "lib/screens/language_screen.dart",
    "lib/screens/notification_settings_screen.dart",
    "lib/screens/support_screen.dart",
    "lib/screens/privacy_screen.dart",
    "lib/screens/ui_settings_screen.dart",
    ".github/workflows/deploy-web.yml",
    "assets/images/place_alem.jpg",
    "assets/images/place_monument.jpg",
    "assets/images/place_arch.jpg",
    "assets/images/place_park.jpg",
    "DESIGN_LOCK.json",
    "docs/STAGE17_REPORT.md",
]
errors = []
for rel in required:
    if not (root / rel).exists():
        errors.append(f"missing: {rel}")

for dart in root.glob("lib/**/*.dart"):
    text = dart.read_text(encoding="utf-8")
    for match in re.finditer(r"import\s+'([^']+)';", text):
        target = match.group(1)
        if target.startswith("package:") or target.startswith("dart:"):
            continue
        resolved = (dart.parent / target).resolve()
        if not resolved.exists():
            errors.append(f"broken import: {dart.relative_to(root)} -> {target}")

lock_text = (root / "DESIGN_LOCK.json").read_text(encoding="utf-8") if (root / "DESIGN_LOCK.json").exists() else ""
for phrase in [
    "room_prices",
    "availability_request",
    "personal_profile",
    "place_detail",
    "dynamic city-specific hotels and places",
    "stage6_scope",
    "in-catalog review modal",
    "ui_settings",
    "mobile Safari and GitHub Pages viewport correction",
    "hidden five-tap designer panel",
    "copyable JSON export",
]:
    if phrase not in lock_text:
        errors.append(f"design lock missing: {phrase}")

if errors:
    print("VALIDATION FAILED")
    for error in errors:
        print("-", error)
    sys.exit(1)

print("VALIDATION OK")
print("Dart files:", len(list(root.glob("lib/**/*.dart"))))
