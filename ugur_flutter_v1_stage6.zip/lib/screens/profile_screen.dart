import 'package:flutter/material.dart';
import '../data/app_state.dart';
import '../theme/app_theme.dart';
import 'language_screen.dart';
import 'login_screen.dart';
import 'notification_settings_screen.dart';
import 'personal_profile_screen.dart';
import 'privacy_screen.dart';
import 'register_screen.dart';
import 'support_screen.dart';
import 'welcome_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  void _push(BuildContext context, Widget screen) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
  }

  Future<void> _logout(BuildContext context) async {
    await AppState.instance.logout();
    if (!context.mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const WelcomeScreen()),
      (_) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppState.instance,
      builder: (_, __) {
        final state = AppState.instance;
        final guest = state.isGuest;
        final profile = state.profile;

        Widget item(
          IconData icon,
          String title,
          VoidCallback onTap, {
          bool danger = false,
        }) =>
            ListTile(
              onTap: onTap,
              leading: Icon(icon, color: danger ? AppColors.danger : AppColors.navy),
              title: Text(
                title,
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  color: danger ? AppColors.danger : null,
                ),
              ),
              trailing: const Icon(Icons.chevron_right),
            );

        return SafeArea(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              Container(
                color: AppColors.navy,
                padding: const EdgeInsets.all(22),
                child: Row(
                  children: [
                    const CircleAvatar(
                      radius: 36,
                      backgroundColor: AppColors.gold,
                      child: Icon(Icons.person, size: 38, color: AppColors.text),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            guest ? 'Гость' : (profile.name.isEmpty ? 'Пользователь Ugur' : profile.name),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 23,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          if (!guest && profile.phone.isNotEmpty)
                            Text(profile.phone, style: const TextStyle(color: Colors.white70)),
                          if (!guest && profile.email.isNotEmpty)
                            Text(profile.email, style: const TextStyle(color: Colors.white70)),
                        ],
                      ),
                    ),
                    if (!guest)
                      IconButton(
                        tooltip: 'Личный профиль',
                        onPressed: () => _push(context, const PersonalProfileScreen()),
                        icon: const Icon(Icons.settings_outlined, color: Colors.white),
                      ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Card(
                  child: Column(
                    children: [
                      if (!guest)
                        item(
                          Icons.person_outline,
                          'Личный профиль',
                          () => _push(context, const PersonalProfileScreen()),
                        ),
                      item(Icons.language, 'Язык', () => _push(context, const LanguageScreen())),
                      item(
                        Icons.notifications_none,
                        'Уведомления',
                        () => _push(context, const NotificationSettingsScreen()),
                      ),
                      item(Icons.support_agent, 'Поддержка', () => _push(context, const SupportScreen())),
                      item(
                        Icons.privacy_tip_outlined,
                        'Конфиденциальность',
                        () => _push(context, const PrivacyScreen()),
                      ),
                      if (!guest)
                        item(Icons.logout, 'Выйти из аккаунта', () => _logout(context), danger: true),
                    ],
                  ),
                ),
              ),
              if (guest)
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                  child: Column(
                    children: [
                      FilledButton.icon(
                        onPressed: () => _push(context, const LoginScreen()),
                        icon: const Icon(Icons.login_rounded),
                        label: const Text('Войти'),
                      ),
                      const SizedBox(height: 10),
                      OutlinedButton.icon(
                        onPressed: () => _push(context, const RegisterScreen()),
                        icon: const Icon(Icons.person_add_alt_1_rounded),
                        label: const Text('Создать аккаунт'),
                        style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(54)),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}
