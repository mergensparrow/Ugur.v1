import 'package:flutter/material.dart';
import '../data/demo_data.dart';
import '../data/favorites_store.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import 'hotel_detail_screen.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ValueListenableBuilder<Set<String>>(
        valueListenable: FavoritesStore.hotels,
        builder: (_, favorites, __) {
          final favoriteHotels = hotels.where((hotel) => favorites.contains(hotel.name)).toList();
          return ListView(
            padding: const EdgeInsets.fromLTRB(18, 20, 18, 28),
            children: [
              const Text('Избранное', style: TextStyle(fontSize: 31, fontWeight: FontWeight.w900, letterSpacing: -.8)),
              const SizedBox(height: 4),
              Text('${favoriteHotels.length} гостиницы', style: const TextStyle(color: AppColors.muted)),
              const SizedBox(height: 18),
              if (favoriteHotels.isEmpty)
                const Padding(
                  padding: EdgeInsets.only(top: 80),
                  child: Column(
                    children: [
                      Icon(Icons.favorite_border_rounded, size: 54, color: AppColors.muted),
                      SizedBox(height: 14),
                      Text('Пока нет избранных гостиниц', style: TextStyle(fontWeight: FontWeight.w800)),
                    ],
                  ),
                )
              else
                ...favoriteHotels.map(
                  (hotel) => Padding(
                    padding: const EdgeInsets.only(bottom: 13),
                    child: Card(
                      clipBehavior: Clip.antiAlias,
                      child: InkWell(
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => HotelDetailScreen(hotel: hotel)),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(18),
                                child: Image.asset(hotel.image, width: 82, height: 82, fit: BoxFit.cover),
                              ),
                              const SizedBox(width: 13),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(hotel.name, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                                    const SizedBox(height: 4),
                                    Text('${hotel.city} · от ${hotel.price} TMT', style: const TextStyle(color: AppColors.muted)),
                                    const SizedBox(height: 7),
                                    Text(
                                      hotel.status.label,
                                      style: TextStyle(
                                        color: hotel.status == AvailabilityStatus.available ? AppColors.success : AppColors.warning,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              IconButton(
                                onPressed: () => FavoritesStore.toggle(hotel.name),
                                icon: const Icon(Icons.favorite_rounded, color: AppColors.danger),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}
