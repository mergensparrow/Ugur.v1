import 'package:flutter/material.dart';
import '../data/app_state.dart';
import '../data/demo_data.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import 'city_picker_screen.dart';
import 'hotel_catalog_screen.dart';
import 'notifications_screen.dart';
import 'place_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String selectedCity = 'Ашхабад';

  static const popularCities = <_CityCardData>[
    _CityCardData('Аваза', 'Курортная зона', 'assets/images/city_avaza.jpg'),
    _CityCardData('Туркменбаши', 'Портовый город', 'assets/images/city_turkmenbashi.jpg'),
    _CityCardData('Дашогуз', 'Исторический город', 'assets/images/city_dashoguz.jpg'),
  ];

  static const otherCities = <_SmallCityData>[
    _SmallCityData('Балканабат', Color(0xFFFFF1D7), Color(0xFFD6921D)),
    _SmallCityData('Мары', Color(0xFFF0E9FF), Color(0xFF7652C6)),
    _SmallCityData('Туркменабад', Color(0xFFE9F8EE), Color(0xFF2E9A58)),
    _SmallCityData('Дашогуз', Color(0xFFE7F4FF), Color(0xFF2788CA)),
  ];

  Future<void> _pickCity() async {
    final value = await Navigator.of(context).push<String>(
      MaterialPageRoute(builder: (_) => CityPickerScreen(initialCity: selectedCity)),
    );
    if (value != null && mounted) setState(() => selectedCity = value);
  }

  void _openCatalog([String? city]) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => HotelCatalogScreen(city: city ?? selectedCity)),
    );
  }

  void _openNotifications() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const NotificationsScreen(showBackButton: true)),
    );
  }

  void _openPlace(TouristPlace place) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => PlaceDetailScreen(place: place)),
    );
  }

  void _showAllPlaces() {
    final places = placesForCity(selectedCity);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(popularPlacesTitle(selectedCity), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 12),
              ...places.map(
                (place) => Card(
                  child: ListTile(
                    onTap: () {
                      Navigator.pop(sheetContext);
                      _openPlace(place);
                    },
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.asset(place.image, width: 58, height: 58, fit: BoxFit.cover),
                    ),
                    title: Text(place.name, style: const TextStyle(fontWeight: FontWeight.w900)),
                    subtitle: Text(place.category),
                    trailing: const Icon(Icons.chevron_right_rounded),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final places = placesForCity(selectedCity);
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 13, 16, 28),
        children: [
          _TopBrand(onNotifications: _openNotifications),
          const SizedBox(height: 18),
          _CityDiscoveryPanel(
            selectedCity: selectedCity,
            places: places,
            onPickCity: _pickCity,
            onOpenPlace: _openPlace,
            onShowAllPlaces: _showAllPlaces,
            onSearchHotels: () => _openCatalog(),
          ),
          const SizedBox(height: 12),
          _CountryDiscoveryPanel(
            popularCities: popularCities,
            otherCities: otherCities,
            onOpenCity: _openCatalog,
          ),
        ],
      ),
    );
  }
}

class _TopBrand extends StatelessWidget {
  const _TopBrand({required this.onNotifications});
  final VoidCallback onNotifications;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Icon(Icons.route_rounded, color: AppColors.gold, size: 44),
        const SizedBox(width: 7),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('ugur', style: TextStyle(fontFamily: 'serif', fontSize: 32, height: 1, fontWeight: FontWeight.w900)),
              SizedBox(height: 4),
              Text(
                'ГОСТИНИЦЫ ТУРКМЕНИСТАНА',
                style: TextStyle(fontSize: 9, letterSpacing: .45, color: AppColors.muted, fontWeight: FontWeight.w700),
              ),
            ],
          ),
        ),
        AnimatedBuilder(
          animation: AppState.instance,
          builder: (_, __) {
            final unread = AppState.instance.unreadNotifications;
            final icon = IconButton(
              tooltip: 'Уведомления',
              onPressed: onNotifications,
              icon: const Icon(Icons.notifications_none_rounded, size: 30),
            );
            return unread > 0 ? Badge(label: Text('$unread'), child: icon) : icon;
          },
        ),
      ],
    );
  }
}

class _CityDiscoveryPanel extends StatelessWidget {
  const _CityDiscoveryPanel({
    required this.selectedCity,
    required this.places,
    required this.onPickCity,
    required this.onOpenPlace,
    required this.onShowAllPlaces,
    required this.onSearchHotels,
  });

  final String selectedCity;
  final List<TouristPlace> places;
  final VoidCallback onPickCity;
  final ValueChanged<TouristPlace> onOpenPlace;
  final VoidCallback onShowAllPlaces;
  final VoidCallback onSearchHotels;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: const Color(0x45D6AC53)),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFFFFAF0), Color(0xFFF0F6FF)],
        ),
        boxShadow: const [BoxShadow(color: Color(0x11000000), blurRadius: 22, offset: Offset(0, 9))],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: Stack(
          children: [
            const Positioned.fill(child: IgnorePointer(child: CustomPaint(painter: _DiscoveryDecorationPainter()))),
            Padding(
              padding: const EdgeInsets.fromLTRB(17, 18, 17, 15),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Куда вы хотите\nпоехать?',
                    style: TextStyle(
                      fontFamily: 'serif',
                      fontSize: 35,
                      height: .98,
                      fontWeight: FontWeight.w900,
                      letterSpacing: -1,
                      color: AppColors.navy,
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Выберите город, чтобы увидеть лучшие\nварианты проживания',
                    style: TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.45),
                  ),
                  const SizedBox(height: 22),
                  Material(
                    color: const Color(0xEFFFFFFF),
                    borderRadius: BorderRadius.circular(24),
                    child: InkWell(
                      onTap: onPickCity,
                      borderRadius: BorderRadius.circular(24),
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(13, 12, 12, 12),
                        child: Row(
                          children: [
                            Container(
                              width: 46,
                              height: 46,
                              decoration: const BoxDecoration(color: Color(0xFFFFF1CA), shape: BoxShape.circle),
                              child: const Icon(Icons.location_on_rounded, color: AppColors.gold, size: 28),
                            ),
                            const SizedBox(width: 11),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text('Выбранный город', style: TextStyle(color: Color(0xFFB7892D), fontSize: 11, fontWeight: FontWeight.w700)),
                                  const SizedBox(height: 2),
                                  Text(selectedCity, style: const TextStyle(fontFamily: 'serif', fontSize: 24, height: 1, fontWeight: FontWeight.w900)),
                                ],
                              ),
                            ),
                            const Icon(Icons.keyboard_arrow_down_rounded, size: 28),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 22),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          popularPlacesTitle(selectedCity),
                          maxLines: 2,
                          style: const TextStyle(fontFamily: 'serif', fontSize: 18, height: 1.05, fontWeight: FontWeight.w900),
                        ),
                      ),
                      TextButton(
                        onPressed: onShowAllPlaces,
                        child: const Text('Смотреть все', style: TextStyle(color: Color(0xFFAD8127), fontSize: 11)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  SizedBox(
                    height: 190,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: places.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemBuilder: (_, index) => _PlaceCard(place: places[index], onTap: () => onOpenPlace(places[index])),
                    ),
                  ),
                  const SizedBox(height: 13),
                  Center(
                    child: Container(
                      width: 110,
                      height: 2,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(99),
                        gradient: const LinearGradient(colors: [AppColors.gold, Color(0xFF8CB7E8)]),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: onSearchHotels,
                    icon: const Icon(Icons.search_rounded),
                    label: const Text('Найти гостиницы'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DiscoveryDecorationPainter extends CustomPainter {
  const _DiscoveryDecorationPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final skyline = Paint()..color = const Color(0x2388A0B6)..style = PaintingStyle.stroke..strokeWidth = 1;
    final baseY = size.height * .32;
    for (var i = 0; i < 8; i++) {
      final x = size.width * (.48 + i * .067);
      final h = 22.0 + (i % 3) * 17;
      canvas.drawRect(Rect.fromLTWH(x, baseY - h, 16, h), skyline);
      canvas.drawLine(Offset(x + 8, baseY - h), Offset(x + 8, baseY - h - 18), skyline);
    }
    final line = Paint()..color = const Color(0x99C69A3B)..style = PaintingStyle.stroke..strokeWidth = 1.35;
    final path = Path()
      ..moveTo(size.width * .28, size.height * .17)
      ..cubicTo(size.width * .48, size.height * .18, size.width * .50, size.height * .30, size.width * .28, size.height * .32)
      ..cubicTo(size.width * .02, size.height * .35, size.width * .02, size.height * .50, size.width * .70, size.height * .55);
    canvas.drawPath(path, line);
    final dot = Paint()..color = const Color(0xFFC59635);
    canvas.drawCircle(Offset(size.width * .28, size.height * .17), 3.2, dot);
    canvas.drawCircle(Offset(size.width * .28, size.height * .32), 3.2, dot);
    canvas.drawCircle(Offset(size.width * .70, size.height * .55), 3.2, dot);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _PlaceCard extends StatelessWidget {
  const _PlaceCard({required this.place, required this.onTap});
  final TouristPlace place;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: SizedBox(
          width: 112,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: Stack(
              fit: StackFit.expand,
              children: [
                Image.asset(place.image, fit: BoxFit.cover),
                const DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Color(0xE8071A2B)]),
                  ),
                ),
                Positioned(
                  left: 8,
                  right: 7,
                  bottom: 9,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(place.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 12, height: 1.08, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 5),
                      Row(
                        children: [
                          const Icon(Icons.location_on_rounded, color: AppColors.gold, size: 12),
                          const SizedBox(width: 2),
                          Expanded(child: Text(place.category, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70, fontSize: 8.5))),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _CountryDiscoveryPanel extends StatelessWidget {
  const _CountryDiscoveryPanel({required this.popularCities, required this.otherCities, required this.onOpenCity});
  final List<_CityCardData> popularCities;
  final List<_SmallCityData> otherCities;
  final ValueChanged<String> onOpenCity;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(13, 14, 13, 15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0x12000000)),
        boxShadow: const [BoxShadow(color: Color(0x0D000000), blurRadius: 18, offset: Offset(0, 7))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Популярные направления', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
          const SizedBox(height: 9),
          SizedBox(
            height: 112,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: popularCities.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, index) => _DestinationCard(data: popularCities[index], onTap: () => onOpenCity(popularCities[index].name)),
            ),
          ),
          const SizedBox(height: 13),
          const Text('Другие города', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
          const SizedBox(height: 9),
          SizedBox(
            height: 104,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: otherCities.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, index) => _OtherCityCard(data: otherCities[index], onTap: () => onOpenCity(otherCities[index].name)),
            ),
          ),
        ],
      ),
    );
  }
}

class _DestinationCard extends StatelessWidget {
  const _DestinationCard({required this.data, required this.onTap});
  final _CityCardData data;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: SizedBox(
        width: 150,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(15),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.asset(data.asset, fit: BoxFit.cover),
              const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Color(0xD9000000)]))),
              Positioned(
                left: 10,
                right: 8,
                bottom: 8,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(data.name, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900)),
                    Text(data.subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70, fontSize: 9.5)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _OtherCityCard extends StatelessWidget {
  const _OtherCityCard({required this.data, required this.onTap});
  final _SmallCityData data;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xFFFCFCFD),
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          width: 100,
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 10),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0x0F000000))),
          child: Column(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(color: data.iconBackground, shape: BoxShape.circle),
                child: Icon(Icons.apartment_rounded, color: data.iconColor, size: 20),
              ),
              const Spacer(),
              Text(data.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 10.5)),
              const SizedBox(height: 2),
              Text('${cityHotelCounts[data.name] ?? 0} гостиниц', style: const TextStyle(color: AppColors.muted, fontSize: 8)),
            ],
          ),
        ),
      ),
    );
  }
}

class _CityCardData {
  const _CityCardData(this.name, this.subtitle, this.asset);
  final String name;
  final String subtitle;
  final String asset;
}

class _SmallCityData {
  const _SmallCityData(this.name, this.iconBackground, this.iconColor);
  final String name;
  final Color iconBackground;
  final Color iconColor;
}
