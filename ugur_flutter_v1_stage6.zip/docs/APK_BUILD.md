# Получение первого APK

## Самый простой способ: GitHub Actions

1. Создайте пустой репозиторий GitHub.
2. Загрузите в него содержимое этой папки.
3. Откройте вкладку **Actions**.
4. Выберите **Build Ugur Android APK**.
5. Нажмите **Run workflow**.
6. После завершения откройте запуск и скачайте artifact `ugur-stage6-debug-apk`.
7. Внутри будет `app-debug.apk`.

## Сборка на компьютере

Нужен Flutter stable и Android SDK.

```bash
./tool/build_debug_apk.sh
```

Результат:

```text
build/app/outputs/flutter-apk/app-debug.apk
```

## Важно

Debug APK предназначен только для первого тестирования. Для Google Play позднее потребуется подписанный AAB.
