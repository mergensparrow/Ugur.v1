import 'package:flutter/foundation.dart';

/// Локальное хранилище избранного для интерфейсного этапа.
/// На серверном этапе будет заменено репозиторием пользователя.
class FavoritesStore {
  FavoritesStore._();

  static final ValueNotifier<Set<String>> hotels =
      ValueNotifier<Set<String>>(<String>{'Yyldyz Hotel', 'Sport Hotel', 'Arçabil Hotel'});

  static bool contains(String hotelName) => hotels.value.contains(hotelName);

  static void toggle(String hotelName) {
    final next = Set<String>.from(hotels.value);
    if (!next.add(hotelName)) {
      next.remove(hotelName);
    }
    hotels.value = next;
  }
}
