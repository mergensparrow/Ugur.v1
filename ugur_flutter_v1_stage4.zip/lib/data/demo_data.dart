import '../models/models.dart';

const cityNames = [
  'Ашхабад',
  'Аваза',
  'Туркменбаши',
  'Балканабат',
  'Дашогуз',
  'Туркменабад',
  'Мары',
  'Куняургенч',
  'Гызыларбат',
];

const hotels = [
  Hotel(
    name: 'Yyldyz Hotel',
    city: 'Ашхабад',
    rating: 4.8,
    reviews: 86,
    price: 850,
    status: AvailabilityStatus.available,
    image: 'assets/images/hotel_yyldyz.jpg',
    description: 'Премиальная гостиница с панорамным видом, ресторанами и современными удобствами.',
    rooms: [
      RoomPrice('Стандарт', '1 человек', 650),
      RoomPrice('Стандарт', '2 человека', 850, tag: 'Популярный выбор'),
      RoomPrice('Полулюкс', '2 человека', 1200),
      RoomPrice('Люкс', '2 человека', 1800),
      RoomPrice('Семейный', '4 человека', 2500, tag: 'Для семьи'),
    ],
  ),
  Hotel(
    name: 'Sport Hotel',
    city: 'Ашхабад',
    rating: 4.5,
    reviews: 42,
    price: 650,
    status: AvailabilityStatus.recheck,
    image: 'assets/images/hotel_sport.jpg',
    description: 'Практичная гостиница рядом со спортивной инфраструктурой.',
    rooms: [
      RoomPrice('Стандарт', '1 человек', 650),
      RoomPrice('Полулюкс', '2 человека', 950),
    ],
  ),
  Hotel(
    name: 'Arçabil Hotel',
    city: 'Ашхабад',
    rating: 4.7,
    reviews: 64,
    price: 720,
    status: AvailabilityStatus.unavailable,
    image: 'assets/images/hotel_archabil.jpg',
    description: 'Современная городская гостиница с просторными номерами.',
    rooms: [
      RoomPrice('Стандарт', '1 человек', 720),
      RoomPrice('Люкс', '2 человека', 1650),
    ],
  ),
];
