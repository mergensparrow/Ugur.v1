import 'package:flutter/material.dart';
import '../data/favorites_store.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import 'availability_request_screen.dart';
import 'room_prices_screen.dart';

class HotelDetailScreen extends StatefulWidget {
  const HotelDetailScreen({super.key, required this.hotel});
  final Hotel hotel;

  @override
  State<HotelDetailScreen> createState() => _HotelDetailScreenState();
}

class _HotelDetailScreenState extends State<HotelDetailScreen> {
  int selectedTab = 0;
  static const tabLabels = ['Об отеле', 'Номера', 'Отзывы', 'Удобства'];

  Hotel get hotel => widget.hotel;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: true,
            stretch: true,
            expandedHeight: 350,
            backgroundColor: Colors.white,
            foregroundColor: AppColors.text,
            title: Text(hotel.name, style: const TextStyle(fontWeight: FontWeight.w900)),
            actions: [
              IconButton.filledTonal(onPressed: () {}, icon: const Icon(Icons.share_outlined)),
              ValueListenableBuilder<Set<String>>(
                valueListenable: FavoritesStore.hotels,
                builder: (_, favorites, __) {
                  final favorite = favorites.contains(hotel.name);
                  return IconButton.filledTonal(
                    onPressed: () => FavoritesStore.toggle(hotel.name),
                    icon: Icon(favorite ? Icons.favorite_rounded : Icons.favorite_border_rounded, color: favorite ? AppColors.danger : null),
                  );
                },
              ),
              const SizedBox(width: 8),
            ],
            flexibleSpace: FlexibleSpaceBar(
              stretchModes: const [StretchMode.zoomBackground],
              background: Stack(
                fit: StackFit.expand,
                children: [
                  Image.asset(hotel.image, fit: BoxFit.cover, filterQuality: FilterQuality.medium),
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Color(0x20000000), Colors.transparent, Color(0x66000000)],
                      ),
                    ),
                  ),
                  Positioned(
                    left: 18,
                    bottom: 15,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
                      decoration: BoxDecoration(color: const Color(0xB5000000), borderRadius: BorderRadius.circular(12)),
                      child: const Text('1 / 24', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 20, 18, 30),
            sliver: SliverList.list(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(hotel.name, style: const TextStyle(fontSize: 29, fontWeight: FontWeight.w900, letterSpacing: -.8)),
                          const SizedBox(height: 5),
                          Text(hotel.city, style: const TextStyle(color: AppColors.muted, fontSize: 14)),
                        ],
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.star_rounded, color: AppColors.gold, size: 23),
                            Text(' ${hotel.rating}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                          ],
                        ),
                        Text('${hotel.reviews} отзывов', style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                _AvailabilityLine(status: hotel.status),
                const SizedBox(height: 18),
                _AmenitiesStrip(compact: true),
                const SizedBox(height: 22),
                Text('от ${hotel.price} TMT / ночь', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
                const SizedBox(height: 5),
                const Text('Цена за стандартный номер', style: TextStyle(color: AppColors.muted, fontSize: 12)),
                const SizedBox(height: 24),
                _HotelTabs(
                  labels: tabLabels,
                  selected: selectedTab,
                  onSelected: (index) => setState(() => selectedTab = index),
                ),
                const SizedBox(height: 18),
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 240),
                  child: _tabContent(selectedTab),
                ),
                const SizedBox(height: 26),
                FilledButton.icon(
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => RoomPricesScreen(hotel: hotel))),
                  icon: const Icon(Icons.payments_outlined),
                  label: const Text('Цены на номера'),
                  style: FilledButton.styleFrom(backgroundColor: AppColors.gold, foregroundColor: AppColors.text),
                ),
                const SizedBox(height: 10),
                FilledButton.icon(
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => AvailabilityRequestScreen(hotel: hotel))),
                  icon: const Icon(Icons.search_rounded),
                  label: const Text('Проверить наличие'),
                ),
                const SizedBox(height: 10),
                FilledButton.icon(
                  onPressed: null,
                  icon: const Icon(Icons.lock_clock_outlined),
                  label: const Text('Онлайн-бронирование · Скоро в Ugur'),
                  style: FilledButton.styleFrom(disabledBackgroundColor: AppColors.text, disabledForegroundColor: Colors.white70),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _tabContent(int index) {
    return switch (index) {
      0 => _AboutTab(hotel: hotel, key: const ValueKey('about')),
      1 => _RoomsTab(hotel: hotel, key: const ValueKey('rooms')),
      2 => const _ReviewsTab(key: ValueKey('reviews')),
      _ => const _AmenitiesTab(key: ValueKey('amenities')),
    };
  }
}

class _HotelTabs extends StatelessWidget {
  const _HotelTabs({required this.labels, required this.selected, required this.onSelected});
  final List<String> labels;
  final int selected;
  final ValueChanged<int> onSelected;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: List.generate(labels.length, (index) {
        final active = selected == index;
        return Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: index == labels.length - 1 ? 0 : 7),
            child: Material(
              color: active ? AppColors.text : Colors.white,
              borderRadius: BorderRadius.circular(15),
              child: InkWell(
                onTap: () => onSelected(index),
                borderRadius: BorderRadius.circular(15),
                child: Container(
                  height: 46,
                  alignment: Alignment.center,
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: const Color(0x10000000)),
                  ),
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(
                      labels[index],
                      style: TextStyle(color: active ? Colors.white : AppColors.text, fontSize: 12, fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      }),
    );
  }
}

class _AboutTab extends StatelessWidget {
  const _AboutTab({super.key, required this.hotel});
  final Hotel hotel;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(17),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Описание отеля', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
                const SizedBox(height: 11),
                Text(
                  '${hotel.name} — современный гостиничный комплекс в ${hotel.city}. ${hotel.description} Комфортные номера, отличный сервис и удобное расположение делают его хорошим выбором как для отдыха, так и для деловых поездок.',
                  style: const TextStyle(fontSize: 14, height: 1.55),
                ),
                const SizedBox(height: 12),
                const Text('Показать больше', style: TextStyle(color: AppColors.gold, fontWeight: FontWeight.w900)),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        const Text('Удобства', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
        const SizedBox(height: 11),
        const Card(child: Padding(padding: EdgeInsets.symmetric(horizontal: 10, vertical: 17), child: _AmenitiesStrip())),
        const SizedBox(height: 22),
        Row(
          children: [
            const Expanded(child: Text('Отзывы гостей', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900))),
            TextButton(onPressed: () {}, child: const Text('Все отзывы ›')),
          ],
        ),
        const SizedBox(height: 9),
        const _ReviewCard(),
      ],
    );
  }
}

class _RoomsTab extends StatelessWidget {
  const _RoomsTab({super.key, required this.hotel});
  final Hotel hotel;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: hotel.rooms.map((room) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 11),
          child: Card(
            child: ListTile(
              contentPadding: const EdgeInsets.all(14),
              leading: const CircleAvatar(backgroundColor: Color(0xFFF2F3F5), child: Icon(Icons.bed_rounded, color: AppColors.text)),
              title: Text(room.name, style: const TextStyle(fontWeight: FontWeight.w900)),
              subtitle: Text(room.capacity),
              trailing: Text('${room.price} TMT', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _ReviewsTab extends StatelessWidget {
  const _ReviewsTab({super.key});

  @override
  Widget build(BuildContext context) {
    return const Column(
      children: [
        _ReviewCard(),
        SizedBox(height: 12),
        _ReviewCard(name: 'Мяхри А.', date: '8 апреля 2026', rating: 4, text: 'Красивый интерьер, чисто и спокойно. Персонал быстро помог с вопросами.'),
      ],
    );
  }
}

class _AmenitiesTab extends StatelessWidget {
  const _AmenitiesTab({super.key});

  @override
  Widget build(BuildContext context) {
    return const Card(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 20),
        child: _AmenitiesStrip(),
      ),
    );
  }
}

class _AmenitiesStrip extends StatelessWidget {
  const _AmenitiesStrip({this.compact = false});
  final bool compact;

  static const items = <(IconData, String)>[
    (Icons.wifi_rounded, 'Wi‑Fi'),
    (Icons.local_parking_outlined, 'Парковка'),
    (Icons.pool_outlined, 'Бассейн'),
    (Icons.restaurant_outlined, 'Ресторан'),
    (Icons.ac_unit_rounded, 'Кондиционер'),
    (Icons.free_breakfast_outlined, 'Завтрак'),
  ];

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: compact ? 70 : 82,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        separatorBuilder: (_, __) => SizedBox(width: compact ? 18 : 21),
        itemBuilder: (_, index) {
          final item = items[index];
          return SizedBox(
            width: compact ? 54 : 62,
            child: Column(
              children: [
                Container(
                  width: compact ? 42 : 47,
                  height: compact ? 42 : 47,
                  decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle, boxShadow: [BoxShadow(color: Color(0x10000000), blurRadius: 11)]),
                  child: Icon(item.$1, size: compact ? 21 : 23),
                ),
                const SizedBox(height: 6),
                Text(item.$2, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: compact ? 9 : 10)),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _AvailabilityLine extends StatelessWidget {
  const _AvailabilityLine({required this.status});
  final AvailabilityStatus status;

  Color get color => switch (status) {
        AvailabilityStatus.available => AppColors.success,
        AvailabilityStatus.unavailable => AppColors.danger,
        AvailabilityStatus.recheck => AppColors.warning,
        AvailabilityStatus.checking => AppColors.gold,
      };

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        CircleAvatar(radius: 5, backgroundColor: color),
        const SizedBox(width: 8),
        Text(status.label, style: TextStyle(color: color, fontWeight: FontWeight.w900)),
      ],
    );
  }
}

class _ReviewCard extends StatelessWidget {
  const _ReviewCard({this.name = 'Алексей Петров', this.date = '12 мая 2024', this.rating = 5, this.text = 'Отличный отель! Чисто, уютно, прекрасный персонал. Обязательно вернусь снова.'});
  final String name;
  final String date;
  final int rating;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const CircleAvatar(backgroundColor: Color(0xFFE9ECF0), child: Icon(Icons.person_rounded)),
                const SizedBox(width: 11),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(name, style: const TextStyle(fontWeight: FontWeight.w900)),
                      Text(date, style: const TextStyle(color: AppColors.muted, fontSize: 11)),
                    ],
                  ),
                ),
                const Icon(Icons.star_rounded, color: AppColors.gold),
                Text('$rating.0', style: const TextStyle(fontWeight: FontWeight.w900)),
              ],
            ),
            const SizedBox(height: 13),
            Text(text, style: const TextStyle(height: 1.45)),
          ],
        ),
      ),
    );
  }
}
