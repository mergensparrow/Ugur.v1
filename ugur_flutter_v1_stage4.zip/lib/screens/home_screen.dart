import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'city_picker_screen.dart';
import 'hotel_catalog_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String selectedCity = 'Ашхабад';
  int pageIndex = 0;
  late final PageController _pageController;

  @override
  void initState() {
    super.initState();
    _pageController = PageController(viewportFraction: .72);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  static const popularCities = <_CityCardData>[
    _CityCardData(
      name: 'Ашхабад',
      subtitle: 'Столица • 87 гостиниц',
      asset: 'assets/images/city_ashgabat.jpg',
    ),
    _CityCardData(
      name: 'Аваза',
      subtitle: 'Курортная зона • 32',
      asset: 'assets/images/city_avaza.jpg',
    ),
    _CityCardData(
      name: 'Туркменбаши',
      subtitle: 'Портовый город • 28',
      asset: 'assets/images/city_turkmenbashi.jpg',
    ),
  ];

  static const otherCities = <_SmallCityData>[
    _SmallCityData('Балканабат', '16 гостиниц', Color(0xFFFFF1D7), Color(0xFFD6921D)),
    _SmallCityData('Дашогуз', '16 гостиниц', Color(0xFFE7F4FF), Color(0xFF2788CA)),
    _SmallCityData('Туркменабад', '22 гостиницы', Color(0xFFE9F8EE), Color(0xFF2E9A58)),
    _SmallCityData('Мары', '20 гостиниц', Color(0xFFF0E9FF), Color(0xFF7652C6)),
  ];

  Future<void> _pickCity() async {
    final value = await Navigator.of(context).push<String>(
      MaterialPageRoute(builder: (_) => CityPickerScreen(initialCity: selectedCity)),
    );
    if (value != null && mounted) {
      setState(() => selectedCity = value);
    }
  }

  void _openCatalog([String? city]) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => HotelCatalogScreen(city: city ?? selectedCity)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 28),
        children: [
          _TopBrand(onNotifications: () {}),
          const SizedBox(height: 28),
          const Text(
            'Куда вы хотите\nпоехать?',
            style: TextStyle(
              fontSize: 34,
              height: 1.04,
              fontWeight: FontWeight.w900,
              letterSpacing: -1.2,
              color: AppColors.text,
            ),
          ),
          const SizedBox(height: 13),
          const Text(
            'Выберите город, чтобы увидеть лучшие\nварианты проживания',
            style: TextStyle(color: AppColors.muted, fontSize: 15, height: 1.45),
          ),
          const SizedBox(height: 23),
          Material(
            color: Colors.white,
            borderRadius: BorderRadius.circular(23),
            child: InkWell(
              onTap: _pickCity,
              borderRadius: BorderRadius.circular(23),
              child: Container(
                padding: const EdgeInsets.fromLTRB(18, 14, 16, 14),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(23),
                  boxShadow: const [
                    BoxShadow(color: Color(0x0D000000), blurRadius: 22, offset: Offset(0, 9)),
                  ],
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Выберите город', style: TextStyle(color: AppColors.muted, fontSize: 12)),
                          const SizedBox(height: 5),
                          Text(selectedCity, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                        ],
                      ),
                    ),
                    const Icon(Icons.keyboard_arrow_down_rounded, size: 28),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 13),
          FilledButton.icon(
            onPressed: _openCatalog,
            icon: const Icon(Icons.search_rounded),
            label: const Text('Найти гостиницы'),
          ),
          const SizedBox(height: 30),
          const Text('Популярные направления', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
          const SizedBox(height: 14),
          _LargeDestinationCard(
            data: popularCities.first,
            onTap: () => _openCatalog(popularCities.first.name),
          ),
          const SizedBox(height: 14),
          SizedBox(
            height: 150,
            child: PageView.builder(
              controller: _pageController,
              padEnds: false,
              itemCount: popularCities.length - 1,
              onPageChanged: (index) => setState(() => pageIndex = index),
              itemBuilder: (_, index) {
                final city = popularCities[index + 1];
                return Padding(
                  padding: EdgeInsets.only(right: index == popularCities.length - 2 ? 0 : 12),
                  child: _SmallDestinationCard(data: city, onTap: () => _openCatalog(city.name)),
                );
              },
            ),
          ),
          const SizedBox(height: 13),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              popularCities.length - 1,
              (index) => AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                margin: const EdgeInsets.symmetric(horizontal: 4),
                width: pageIndex == index ? 8 : 6,
                height: pageIndex == index ? 8 : 6,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: pageIndex == index ? AppColors.muted : const Color(0xFFD6D8DC),
                ),
              ),
            ),
          ),
          const SizedBox(height: 23),
          const Text('Другие города', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          const SizedBox(height: 13),
          SizedBox(
            height: 126,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: otherCities.length,
              separatorBuilder: (_, __) => const SizedBox(width: 11),
              itemBuilder: (_, index) {
                final city = otherCities[index];
                return _OtherCityCard(data: city, onTap: () => _openCatalog(city.name));
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _TopBrand extends StatelessWidget {
  const _TopBrand({required this.onNotifications});
  final VoidCallback onNotifications;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 48,
          height: 48,
          alignment: Alignment.center,
          child: const Icon(Icons.route_rounded, color: AppColors.gold, size: 43),
        ),
        const SizedBox(width: 6),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('ugur', style: TextStyle(fontSize: 31, height: 1, fontWeight: FontWeight.w900, letterSpacing: -1)),
              SizedBox(height: 5),
              Text(
                'ГОСТИНИЦЫ ТУРКМЕНИСТАНА',
                style: TextStyle(fontSize: 9, letterSpacing: .55, color: AppColors.muted, fontWeight: FontWeight.w700),
              ),
            ],
          ),
        ),
        Badge(
          label: const Text('2'),
          child: IconButton(
            onPressed: onNotifications,
            icon: const Icon(Icons.notifications_none_rounded, size: 30),
          ),
        ),
      ],
    );
  }
}

class _LargeDestinationCard extends StatelessWidget {
  const _LargeDestinationCard({required this.data, required this.onTap});
  final _CityCardData data;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: SizedBox(
        height: 155,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.asset(data.asset, fit: BoxFit.cover, filterQuality: FilterQuality.medium),
              const DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Color(0xD9000000)],
                  ),
                ),
              ),
              Positioned(
                left: 18,
                right: 18,
                bottom: 16,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(data.name, style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 3),
                    Text(data.subtitle, style: const TextStyle(color: Colors.white70, fontSize: 12)),
                  ],
                ),
              ),
              Positioned(
                top: 13,
                right: 13,
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                  child: const Icon(Icons.star_rounded, color: AppColors.gold),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SmallDestinationCard extends StatelessWidget {
  const _SmallDestinationCard({required this.data, required this.onTap});
  final _CityCardData data;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(data.asset, fit: BoxFit.cover, filterQuality: FilterQuality.medium),
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Color(0xD8000000)]),
              ),
            ),
            Positioned(
              left: 15,
              right: 12,
              bottom: 13,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(data.name, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 3),
                  Text(data.subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70, fontSize: 11)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OtherCityCard extends StatelessWidget {
  const _OtherCityCard({required this.data, required this.onTap});
  final _SmallCityData data;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          width: 112,
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 13),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            boxShadow: const [BoxShadow(color: Color(0x0C000000), blurRadius: 16, offset: Offset(0, 6))],
          ),
          child: Column(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(color: data.iconBackground, shape: BoxShape.circle),
                child: Icon(Icons.apartment_rounded, color: data.iconColor, size: 22),
              ),
              const Spacer(),
              Text(data.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12)),
              const SizedBox(height: 3),
              Text(data.subtitle, style: const TextStyle(color: AppColors.muted, fontSize: 9)),
            ],
          ),
        ),
      ),
    );
  }
}

class _CityCardData {
  const _CityCardData({required this.name, required this.subtitle, required this.asset});
  final String name;
  final String subtitle;
  final String asset;
}

class _SmallCityData {
  const _SmallCityData(this.name, this.subtitle, this.iconBackground, this.iconColor);
  final String name;
  final String subtitle;
  final Color iconBackground;
  final Color iconColor;
}
