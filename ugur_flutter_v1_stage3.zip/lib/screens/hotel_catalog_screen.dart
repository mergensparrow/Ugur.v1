import 'package:flutter/material.dart';
import '../data/demo_data.dart';
import '../data/favorites_store.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import 'hotel_detail_screen.dart';

class HotelCatalogScreen extends StatefulWidget {
  const HotelCatalogScreen({super.key, required this.city});
  final String city;

  @override
  State<HotelCatalogScreen> createState() => _HotelCatalogScreenState();
}

class _HotelCatalogScreenState extends State<HotelCatalogScreen> {
  String? activeFilter;

  List<Hotel> get cityHotels {
    final result = hotels.where((hotel) => hotel.city == widget.city).toList();
    if (result.isEmpty && widget.city != 'Ашхабад') {
      return hotels;
    }
    if (activeFilter == 'Цена') {
      result.sort((a, b) => a.price.compareTo(b.price));
    } else if (activeFilter == 'Рейтинг') {
      result.sort((a, b) => b.rating.compareTo(a.rating));
    } else if (activeFilter == 'Наличие') {
      result.sort((a, b) => _availabilityOrder(a.status).compareTo(_availabilityOrder(b.status)));
    }
    return result;
  }

  int _availabilityOrder(AvailabilityStatus status) => switch (status) {
        AvailabilityStatus.available => 0,
        AvailabilityStatus.checking => 1,
        AvailabilityStatus.recheck => 2,
        AvailabilityStatus.unavailable => 3,
      };

  void _toggleFilter(String value) {
    setState(() => activeFilter = activeFilter == value ? null : value);
  }

  void _openHotel(Hotel hotel) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => HotelDetailScreen(hotel: hotel)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final list = cityHotels;
    final foundCount = widget.city == 'Ашхабад' ? 87 : list.length;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        toolbarHeight: 74,
        titleSpacing: 20,
        automaticallyImplyLeading: false,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(widget.city, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: -.7)),
                const SizedBox(width: 4),
                const Icon(Icons.keyboard_arrow_down_rounded, size: 25),
              ],
            ),
            const SizedBox(height: 2),
            Text('$foundCount гостиниц найдено', style: const TextStyle(fontSize: 13, color: AppColors.muted)),
          ],
        ),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.map_outlined, size: 29)),
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Badge(
              label: const Text('2'),
              child: IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none_rounded, size: 29)),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          SizedBox(
            height: 64,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.fromLTRB(18, 8, 18, 8),
              children: [
                _FilterPill(icon: Icons.savings_outlined, label: 'Цена', selected: activeFilter == 'Цена', onTap: () => _toggleFilter('Цена')),
                _FilterPill(icon: Icons.star_rounded, label: 'Рейтинг', selected: activeFilter == 'Рейтинг', onTap: () => _toggleFilter('Рейтинг')),
                _FilterPill(icon: Icons.location_on_outlined, label: 'Наличие', selected: activeFilter == 'Наличие', onTap: () => _toggleFilter('Наличие')),
                _FilterPill(icon: Icons.tune_rounded, label: 'Фильтры', selected: activeFilter == 'Фильтры', onTap: () => _toggleFilter('Фильтры')),
              ],
            ),
          ),
          Expanded(
            child: ValueListenableBuilder<Set<String>>(
              valueListenable: FavoritesStore.hotels,
              builder: (_, favorites, __) {
                return ListView.separated(
                  padding: const EdgeInsets.fromLTRB(18, 8, 18, 26),
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 14),
                  itemBuilder: (_, index) {
                    final hotel = list[index];
                    if (index == 0) {
                      return _FeaturedHotelCard(
                        hotel: hotel,
                        isFavorite: favorites.contains(hotel.name),
                        onFavorite: () => FavoritesStore.toggle(hotel.name),
                        onTap: () => _openHotel(hotel),
                      );
                    }
                    return _CompactHotelCard(
                      hotel: hotel,
                      isFavorite: favorites.contains(hotel.name),
                      onFavorite: () => FavoritesStore.toggle(hotel.name),
                      onTap: () => _openHotel(hotel),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _FilterPill extends StatelessWidget {
  const _FilterPill({required this.icon, required this.label, required this.selected, required this.onTap});
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 10),
      child: Material(
        color: selected ? const Color(0xFFFFF4D7) : Colors.white,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(18),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              boxShadow: const [BoxShadow(color: Color(0x0D000000), blurRadius: 13, offset: Offset(0, 5))],
            ),
            child: Row(
              children: [
                Icon(icon, color: selected ? AppColors.gold : AppColors.text, size: 19),
                const SizedBox(width: 7),
                Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _FeaturedHotelCard extends StatelessWidget {
  const _FeaturedHotelCard({required this.hotel, required this.isFavorite, required this.onFavorite, required this.onTap});
  final Hotel hotel;
  final bool isFavorite;
  final VoidCallback onFavorite;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                Image.asset(hotel.image, width: double.infinity, height: 176, fit: BoxFit.cover, filterQuality: FilterQuality.medium),
                Positioned(
                  top: 13,
                  right: 13,
                  child: _FavoriteButton(isFavorite: isFavorite, onPressed: onFavorite, darkBackground: true),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(17, 14, 17, 0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(hotel.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: -.4)),
                        const SizedBox(height: 5),
                        Text(hotel.city, style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                      ],
                    ),
                  ),
                  _StatusBadge(status: hotel.status),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(17, 13, 17, 14),
              child: Row(
                children: [
                  const Icon(Icons.star_rounded, color: AppColors.gold, size: 24),
                  Text(' ${hotel.rating}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                  Text(' (${hotel.reviews} отзывов)', style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                  const Spacer(),
                  Text('от ${hotel.price} TMT', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                  const Text(' / ночь', style: TextStyle(fontSize: 12, color: AppColors.muted)),
                ],
              ),
            ),
            const Divider(height: 1),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 11),
              child: Row(
                children: [
                  const Icon(Icons.star_border_rounded, size: 22),
                  Text(' ${hotel.rating}', style: const TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(width: 13),
                  const Icon(Icons.chat_bubble_outline_rounded, size: 20),
                  Text(' ${hotel.reviews}', style: const TextStyle(fontWeight: FontWeight.w700)),
                  const Spacer(),
                  IconButton(onPressed: onFavorite, icon: Icon(isFavorite ? Icons.bookmark_rounded : Icons.bookmark_border_rounded)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CompactHotelCard extends StatelessWidget {
  const _CompactHotelCard({required this.hotel, required this.isFavorite, required this.onFavorite, required this.onTap});
  final Hotel hotel;
  final bool isFavorite;
  final VoidCallback onFavorite;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: SizedBox(
          height: 220,
          child: Row(
            children: [
              SizedBox(
                width: 156,
                height: double.infinity,
                child: Image.asset(hotel.image, fit: BoxFit.cover, filterQuality: FilterQuality.medium),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(15, 13, 10, 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(child: Text(hotel.name, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, letterSpacing: -.4))),
                          _FavoriteButton(isFavorite: isFavorite, onPressed: onFavorite),
                        ],
                      ),
                      if (hotel.status == AvailabilityStatus.recheck) ...[
                        const SizedBox(height: 5),
                        _StatusBadge(status: hotel.status),
                      ],
                      const SizedBox(height: 5),
                      Text(hotel.city, style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                      const SizedBox(height: 9),
                      Row(
                        children: [
                          const Icon(Icons.star_rounded, color: AppColors.gold, size: 21),
                          Text(' ${hotel.rating}', style: const TextStyle(fontWeight: FontWeight.w900)),
                          Expanded(child: Text(' (${hotel.reviews} отзыва)', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.muted, fontSize: 11))),
                        ],
                      ),
                      const SizedBox(height: 13),
                      Text('от ${hotel.price} TMT', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                      const Text('/ ночь', style: TextStyle(color: AppColors.muted, fontSize: 11)),
                      const Spacer(),
                      const Divider(height: 1),
                      const SizedBox(height: 7),
                      Row(
                        children: [
                          const Icon(Icons.star_border_rounded, size: 20),
                          Text(' ${hotel.rating}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                          const SizedBox(width: 10),
                          const Icon(Icons.chat_bubble_outline_rounded, size: 18),
                          Text(' ${hotel.reviews}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                          const Spacer(),
                          Icon(isFavorite ? Icons.bookmark_rounded : Icons.bookmark_border_rounded, size: 23),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FavoriteButton extends StatelessWidget {
  const _FavoriteButton({required this.isFavorite, required this.onPressed, this.darkBackground = false});
  final bool isFavorite;
  final VoidCallback onPressed;
  final bool darkBackground;

  @override
  Widget build(BuildContext context) {
    return IconButton(
      onPressed: onPressed,
      visualDensity: VisualDensity.compact,
      style: IconButton.styleFrom(
        backgroundColor: darkBackground ? const Color(0x99000000) : Colors.transparent,
        foregroundColor: darkBackground ? Colors.white : (isFavorite ? AppColors.danger : AppColors.text),
      ),
      icon: Icon(isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  const _StatusBadge({required this.status});
  final AvailabilityStatus status;

  Color get color => switch (status) {
        AvailabilityStatus.available => AppColors.success,
        AvailabilityStatus.unavailable => AppColors.danger,
        AvailabilityStatus.recheck => AppColors.warning,
        AvailabilityStatus.checking => AppColors.gold,
      };

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(color: color.withAlpha(36), borderRadius: BorderRadius.circular(14)),
      child: Text(status.label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w900)),
    );
  }
}
