import 'package:flutter/material.dart';
import '../data/demo_data.dart';
import '../data/favorites_store.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import 'hotel_detail_screen.dart';

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});

  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  int selectedTab = 0;

  List<Hotel> _filtered(List<Hotel> source) {
    return switch (selectedTab) {
      1 => source.where((hotel) => hotel.status == AvailabilityStatus.available).toList(),
      2 => source
          .where((hotel) =>
              hotel.status == AvailabilityStatus.recheck ||
              hotel.status == AvailabilityStatus.checking)
          .toList(),
      _ => source,
    };
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ValueListenableBuilder<Set<String>>(
        valueListenable: FavoritesStore.hotels,
        builder: (_, favorites, __) {
          final favoriteHotels = hotels.where((hotel) => favorites.contains(hotel.name)).toList();
          final visible = _filtered(favoriteHotels);
          final availableCount = favoriteHotels.where((hotel) => hotel.status == AvailabilityStatus.available).length;
          final clarifyCount = favoriteHotels
              .where((hotel) =>
                  hotel.status == AvailabilityStatus.recheck ||
                  hotel.status == AvailabilityStatus.checking)
              .length;

          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
            children: [
              _FavoritesHeader(count: favoriteHotels.length),
              const SizedBox(height: 22),
              _SegmentTabs(
                selectedIndex: selectedTab,
                labels: [
                  'Все ${favoriteHotels.length}',
                  'С номерами $availableCount',
                  'Нужно уточнить $clarifyCount',
                ],
                onSelected: (value) => setState(() => selectedTab = value),
              ),
              const SizedBox(height: 24),
              if (visible.isEmpty)
                const _EmptyFavorites()
              else
                ...visible.map(
                  (hotel) => Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: _FavoriteHotelCard(
                      hotel: hotel,
                      onOpen: () => Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => HotelDetailScreen(hotel: hotel)),
                      ),
                      onFavorite: () => FavoritesStore.toggle(hotel.name),
                    ),
                  ),
                ),
              if (favoriteHotels.isNotEmpty) ...[
                const SizedBox(height: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF4F7FC),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.notifications_none_rounded, color: AppColors.navy),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Статус обновляется после ответа оператора',
                          style: TextStyle(color: AppColors.muted, fontSize: 12.5),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          );
        },
      ),
    );
  }
}

class _FavoritesHeader extends StatelessWidget {
  const _FavoritesHeader({required this.count});
  final int count;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 178,
      child: Stack(
        children: [
          const Positioned.fill(child: CustomPaint(painter: _FavoritesHeaderPainter())),
          Positioned(
            left: 4,
            top: 56,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Избранное',
                  style: TextStyle(
                    fontSize: 44,
                    height: 1,
                    letterSpacing: -1.2,
                    color: AppColors.navy,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  '$count сохранённые гостиницы',
                  style: const TextStyle(fontSize: 18, color: AppColors.muted),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FavoritesHeaderPainter extends CustomPainter {
  const _FavoritesHeaderPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final faint = Paint()
      ..color = const Color(0x217FA1C7)
      ..style = PaintingStyle.stroke
      ..strokeWidth = .8;
    final baseY = size.height * .86;
    for (var i = 0; i < 12; i++) {
      final x = size.width * (.53 + i * .045);
      final h = 12.0 + (i % 4) * 9;
      canvas.drawRect(Rect.fromLTWH(x, baseY - h, 12, h), faint);
      canvas.drawLine(Offset(x + 6, baseY - h), Offset(x + 6, baseY - h - 10), faint);
    }

    final gold = Paint()
      ..color = const Color(0xFFCB982B)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.35;
    final heart = Path()
      ..moveTo(size.width * .73, size.height * .62)
      ..cubicTo(size.width * .60, size.height * .49, size.width * .64, size.height * .23, size.width * .77, size.height * .26)
      ..cubicTo(size.width * .87, size.height * .14, size.width * 1.02, size.height * .30, size.width * .90, size.height * .48)
      ..cubicTo(size.width * .84, size.height * .56, size.width * .77, size.height * .61, size.width * .73, size.height * .62);
    canvas.drawPath(heart, gold);

    final route = Path()
      ..moveTo(size.width * .42, baseY)
      ..cubicTo(size.width * .56, baseY - 2, size.width * .54, size.height * .62, size.width * .68, size.height * .57);
    canvas.drawPath(route, gold);
    final dot = Paint()..color = const Color(0xFFCB982B);
    final white = Paint()..color = Colors.white;
    for (final p in [
      Offset(size.width * .54, size.height * .74),
      Offset(size.width * .67, size.height * .58),
    ]) {
      canvas.drawCircle(p, 5.5, dot);
      canvas.drawCircle(p, 2.0, white);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _SegmentTabs extends StatelessWidget {
  const _SegmentTabs({
    required this.selectedIndex,
    required this.labels,
    required this.onSelected,
  });

  final int selectedIndex;
  final List<String> labels;
  final ValueChanged<int> onSelected;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 58,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: List.generate(labels.length, (index) {
          final selected = index == selectedIndex;
          return Expanded(
            child: InkWell(
              onTap: () => onSelected(index),
              borderRadius: BorderRadius.circular(16),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 210),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: selected ? AppColors.navy : Colors.transparent,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                  labels[index],
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: selected ? Colors.white : AppColors.navy,
                    fontSize: 13.5,
                    fontWeight: selected ? FontWeight.w800 : FontWeight.w500,
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

class _FavoriteHotelCard extends StatelessWidget {
  const _FavoriteHotelCard({
    required this.hotel,
    required this.onOpen,
    required this.onFavorite,
  });

  final Hotel hotel;
  final VoidCallback onOpen;
  final VoidCallback onFavorite;

  Color get statusColor => switch (hotel.status) {
        AvailabilityStatus.available => AppColors.success,
        AvailabilityStatus.unavailable => AppColors.danger,
        AvailabilityStatus.recheck || AvailabilityStatus.checking => AppColors.warning,
      };

  IconData get statusIcon => switch (hotel.status) {
        AvailabilityStatus.available => Icons.check_circle_outline_rounded,
        AvailabilityStatus.unavailable => Icons.remove_circle_outline_rounded,
        AvailabilityStatus.recheck || AvailabilityStatus.checking => Icons.schedule_rounded,
      };

  String get statusText => switch (hotel.status) {
        AvailabilityStatus.available => 'Номера есть',
        AvailabilityStatus.unavailable => 'Свободных номеров нет',
        AvailabilityStatus.recheck || AvailabilityStatus.checking => 'Наличие не подтверждено',
      };

  String get checkedText => switch (hotel.status) {
        AvailabilityStatus.available || AvailabilityStatus.unavailable => 'Проверено сегодня, 09:00',
        AvailabilityStatus.recheck || AvailabilityStatus.checking => 'Последняя проверка вчера, 18:40',
      };

  @override
  Widget build(BuildContext context) {
    final showOperator = hotel.status == AvailabilityStatus.recheck || hotel.status == AvailabilityStatus.checking;
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(24),
      child: InkWell(
        onTap: onOpen,
        borderRadius: BorderRadius.circular(24),
        child: Container(
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: AppColors.border),
            boxShadow: const [BoxShadow(color: Color(0x10031B4E), blurRadius: 18, offset: Offset(0, 7))],
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: Image.asset(hotel.image, width: 116, height: showOperator ? 164 : 132, fit: BoxFit.cover),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Text(
                            hotel.name,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontFamily: 'serif',
                              fontSize: 21,
                              height: 1.03,
                              color: AppColors.navy,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                        IconButton(
                          onPressed: onFavorite,
                          visualDensity: VisualDensity.compact,
                          padding: EdgeInsets.zero,
                          constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
                          icon: const Icon(Icons.favorite_rounded, color: AppColors.danger, size: 29),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${hotel.city}  ·  от ${hotel.price} TMT',
                      style: const TextStyle(color: AppColors.muted, fontSize: 14),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Icon(statusIcon, color: statusColor, size: 22),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            statusText,
                            maxLines: 2,
                            style: TextStyle(color: statusColor, fontSize: 14, fontWeight: FontWeight.w600),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 9),
                    Text(checkedText, style: const TextStyle(color: AppColors.muted, fontSize: 12.5)),
                    if (showOperator) ...[
                      const SizedBox(height: 10),
                      OutlinedButton.icon(
                        onPressed: onOpen,
                        icon: const Icon(Icons.support_agent_rounded, size: 18),
                        label: const Text('Уточнить у оператора'),
                        style: OutlinedButton.styleFrom(
                          minimumSize: const Size.fromHeight(42),
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              const Padding(
                padding: EdgeInsets.only(top: 53),
                child: Icon(Icons.chevron_right_rounded, color: AppColors.navy, size: 27),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EmptyFavorites extends StatelessWidget {
  const _EmptyFavorites();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.only(top: 76, bottom: 120),
      child: Column(
        children: [
          Icon(Icons.favorite_border_rounded, size: 62, color: AppColors.muted),
          SizedBox(height: 16),
          Text('Пока нет избранных гостиниц', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}
