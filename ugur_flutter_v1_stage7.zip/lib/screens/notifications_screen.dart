import 'package:flutter/material.dart';
import '../data/app_state.dart';
import '../theme/app_theme.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key, this.showBackButton = false});

  final bool showBackButton;

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  bool onlyNew = false;

  static const items = <_NotificationItem>[
    _NotificationItem(
      icon: Icons.check_rounded,
      color: AppColors.success,
      background: Color(0xFFECFAF0),
      title: 'Номер подтверждён',
      subtitle: 'Yyldyz Hotel · 2 гостя · Стандарт',
      time: '1 мин',
      initiallyNew: true,
      group: 'Сегодня',
    ),
    _NotificationItem(
      icon: Icons.schedule_rounded,
      color: AppColors.warning,
      background: Color(0xFFFFF5E4),
      title: 'Оператор проверяет',
      subtitle: 'Mary Hotel · уточняем наличие',
      time: '12 мин',
      initiallyNew: true,
      group: 'Сегодня',
    ),
    _NotificationItem(
      icon: Icons.send_rounded,
      color: AppColors.navy,
      background: Color(0xFFEDF4FF),
      title: 'Запрос отправлен',
      subtitle: 'Yyldyz Hotel передан оператору',
      time: '01:42',
      initiallyNew: false,
      group: 'Сегодня',
    ),
    _NotificationItem(
      icon: Icons.remove_rounded,
      color: AppColors.danger,
      background: Color(0xFFFFECEE),
      title: 'Свободных номеров нет',
      subtitle: 'Ak Altyn Hotel',
      time: 'Вчера',
      initiallyNew: false,
      group: 'Ранее',
    ),
  ];

  @override
  void initState() {
    super.initState();
    if (widget.showBackButton) {
      WidgetsBinding.instance.addPostFrameCallback((_) => AppState.instance.markNotificationsRead());
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppState.instance,
      builder: (_, __) {
        final cleared = AppState.instance.notificationsCleared;
        final unread = AppState.instance.unreadNotifications;
        final available = cleared ? const <_NotificationItem>[] : items;
        final visible = onlyNew
            ? available.where((item) => item.initiallyNew && unread > 0).toList()
            : available;

        return Scaffold(
          backgroundColor: Colors.white,
          appBar: widget.showBackButton
              ? AppBar(
                  title: const Text('Уведомления', style: TextStyle(fontWeight: FontWeight.w800)),
                )
              : null,
          body: SafeArea(
            top: !widget.showBackButton,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(18, 22, 18, 28),
              children: [
                if (!widget.showBackButton)
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Уведомления',
                              style: TextStyle(
                                fontSize: 39,
                                height: 1,
                                letterSpacing: -1,
                                color: AppColors.navy,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 12),
                            Text('$unread новых', style: const TextStyle(fontSize: 18, color: AppColors.muted)),
                          ],
                        ),
                      ),
                      OutlinedButton.icon(
                        onPressed: available.isEmpty ? null : () => AppState.instance.markNotificationsRead(),
                        icon: const Icon(Icons.done_all_rounded, size: 20),
                        label: const Text('Прочитать все'),
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: AppColors.border),
                          minimumSize: const Size(142, 50),
                        ),
                      ),
                    ],
                  )
                else
                  Align(
                    alignment: Alignment.centerRight,
                    child: OutlinedButton.icon(
                      onPressed: available.isEmpty ? null : () => AppState.instance.markNotificationsRead(),
                      icon: const Icon(Icons.done_all_rounded, size: 20),
                      label: const Text('Прочитать все'),
                      style: OutlinedButton.styleFrom(side: const BorderSide(color: AppColors.border)),
                    ),
                  ),
                const SizedBox(height: 27),
                _NotificationTabs(
                  onlyNew: onlyNew,
                  unread: unread,
                  onChanged: (value) => setState(() => onlyNew = value),
                ),
                const SizedBox(height: 31),
                if (visible.isEmpty)
                  const _EmptyNotifications()
                else ...[
                  for (final group in const ['Сегодня', 'Ранее']) ...[
                    if (visible.any((item) => item.group == group)) ...[
                      Text(group, style: const TextStyle(fontSize: 15, color: AppColors.muted)),
                      const SizedBox(height: 10),
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: AppColors.border),
                        ),
                        child: Column(
                          children: [
                            for (final item in visible.where((item) => item.group == group)) ...[
                              _NotificationRow(item: item, unread: unread),
                              if (item != visible.where((candidate) => candidate.group == group).last)
                                const Divider(height: 1, indent: 78),
                            ],
                          ],
                        ),
                      ),
                      const SizedBox(height: 26),
                    ],
                  ],
                  Center(
                    child: TextButton.icon(
                      onPressed: () => AppState.instance.clearNotifications(),
                      icon: const Icon(Icons.delete_outline_rounded, color: AppColors.danger),
                      label: const Text('Очистить уведомления', style: TextStyle(color: AppColors.danger)),
                    ),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}

class _NotificationTabs extends StatelessWidget {
  const _NotificationTabs({required this.onlyNew, required this.unread, required this.onChanged});
  final bool onlyNew;
  final int unread;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 57,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Expanded(
            child: _TabButton(label: 'Все', selected: !onlyNew, onTap: () => onChanged(false)),
          ),
          Expanded(
            child: _TabButton(label: 'Новые $unread', selected: onlyNew, onTap: () => onChanged(true)),
          ),
        ],
      ),
    );
  }
}

class _TabButton extends StatelessWidget {
  const _TabButton({required this.label, required this.selected, required this.onTap});
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(15),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 210),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: selected ? AppColors.navy : Colors.transparent,
          borderRadius: BorderRadius.circular(15),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selected ? Colors.white : AppColors.navy,
            fontSize: 15,
            fontWeight: selected ? FontWeight.w800 : FontWeight.w500,
          ),
        ),
      ),
    );
  }
}

class _NotificationRow extends StatelessWidget {
  const _NotificationRow({required this.item, required this.unread});
  final _NotificationItem item;
  final int unread;

  @override
  Widget build(BuildContext context) {
    final isNew = item.initiallyNew && unread > 0;
    return InkWell(
      onTap: () => AppState.instance.markNotificationsRead(),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(13, 16, 10, 16),
        child: Row(
          children: [
            Container(
              width: 51,
              height: 51,
              decoration: BoxDecoration(color: item.background, borderRadius: BorderRadius.circular(16)),
              child: Icon(item.icon, color: item.color, size: 29),
            ),
            const SizedBox(width: 13),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item.title, style: const TextStyle(fontSize: 15.5, color: AppColors.navy, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  Text(item.subtitle, style: const TextStyle(fontSize: 12.5, color: AppColors.muted)),
                ],
              ),
            ),
            const SizedBox(width: 7),
            Text(item.time, style: const TextStyle(fontSize: 11.5, color: AppColors.muted)),
            if (isNew) ...[
              const SizedBox(width: 8),
              Container(width: 9, height: 9, decoration: const BoxDecoration(color: AppColors.gold, shape: BoxShape.circle)),
            ],
            const SizedBox(width: 8),
            const Icon(Icons.chevron_right_rounded, color: AppColors.navy),
          ],
        ),
      ),
    );
  }
}

class _EmptyNotifications extends StatelessWidget {
  const _EmptyNotifications();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.only(top: 80, bottom: 120),
      child: Column(
        children: [
          Icon(Icons.notifications_none_rounded, size: 62, color: AppColors.muted),
          SizedBox(height: 16),
          Text('Уведомлений пока нет', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}

class _NotificationItem {
  const _NotificationItem({
    required this.icon,
    required this.color,
    required this.background,
    required this.title,
    required this.subtitle,
    required this.time,
    required this.initiallyNew,
    required this.group,
  });

  final IconData icon;
  final Color color;
  final Color background;
  final String title;
  final String subtitle;
  final String time;
  final bool initiallyNew;
  final String group;
}
