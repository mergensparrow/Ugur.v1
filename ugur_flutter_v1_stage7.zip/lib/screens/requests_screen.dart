import 'package:flutter/material.dart';
import '../data/demo_data.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import 'hotel_detail_screen.dart';

class RequestsScreen extends StatefulWidget {
  const RequestsScreen({super.key});

  @override
  State<RequestsScreen> createState() => _RequestsScreenState();
}

class _RequestsScreenState extends State<RequestsScreen> {
  int selectedTab = 0;

  Hotel _hotel(String name) => hotels.firstWhere((hotel) => hotel.name == name);

  void _openHotel(Hotel hotel) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => HotelDetailScreen(hotel: hotel)));
  }

  void _showHelp() {
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Как работают запросы'),
        content: const Text(
          'После отправки оператор Ugur связывается с гостиницей и обновляет статус. '
          'Когда ответ будет готов, приложение покажет уведомление.',
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Понятно'))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final active = _hotel('Yyldyz Hotel');
    final completed = [_hotel('Sport Hotel'), _hotel('Ak Altyn Hotel')];
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
        children: [
          _RequestsHeader(onHelp: _showHelp),
          const SizedBox(height: 20),
          _RequestTabs(
            selectedIndex: selectedTab,
            onSelected: (value) => setState(() => selectedTab = value),
          ),
          const SizedBox(height: 22),
          if (selectedTab != 2)
            _ActiveRequestCard(hotel: active),
          if (selectedTab == 0) const SizedBox(height: 22),
          if (selectedTab != 1) ...[
            const Text(
              'Завершённые',
              style: TextStyle(fontSize: 24, color: AppColors.navy, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 12),
            ...completed.map(
              (hotel) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: _CompletedRequestCard(hotel: hotel, onOpen: () => _openHotel(hotel)),
              ),
            ),
          ],
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
            decoration: BoxDecoration(
              color: const Color(0xFFF3F7FD),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Row(
              children: [
                Icon(Icons.notifications_none_rounded, color: AppColors.navy),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Когда оператор ответит, мы отправим уведомление',
                    style: TextStyle(color: AppColors.muted, fontSize: 12.5),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _RequestsHeader extends StatelessWidget {
  const _RequestsHeader({required this.onHelp});
  final VoidCallback onHelp;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 185,
      child: Stack(
        children: [
          const Positioned.fill(child: CustomPaint(painter: _RequestsHeaderPainter())),
          Positioned(
            left: 2,
            top: 72,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text(
                  'Запросы',
                  style: TextStyle(
                    fontSize: 45,
                    height: 1,
                    letterSpacing: -1,
                    color: AppColors.navy,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                SizedBox(height: 12),
                Text(
                  'Проверки наличия и ответы операторов',
                  style: TextStyle(color: AppColors.muted, fontSize: 16),
                ),
              ],
            ),
          ),
          Positioned(
            right: 3,
            top: 12,
            child: Material(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              child: InkWell(
                onTap: onHelp,
                borderRadius: BorderRadius.circular(16),
                child: Container(
                  width: 54,
                  height: 54,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: const Icon(Icons.help_outline_rounded, color: AppColors.navy, size: 30),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _RequestsHeaderPainter extends CustomPainter {
  const _RequestsHeaderPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final faint = Paint()
      ..color = const Color(0x1F7FA1C7)
      ..style = PaintingStyle.stroke
      ..strokeWidth = .8;
    for (var i = 0; i < 9; i++) {
      final x = size.width * (.60 + i * .047);
      final base = size.height * .37;
      final h = 14.0 + (i % 3) * 13;
      canvas.drawRect(Rect.fromLTWH(x, base - h, 13, h), faint);
      canvas.drawLine(Offset(x + 6.5, base - h), Offset(x + 6.5, base - h - 11), faint);
    }
    final gold = Paint()
      ..color = const Color(0xFFCB982B)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4;
    final p = Path()
      ..moveTo(size.width * .42, size.height * .50)
      ..cubicTo(size.width * .60, size.height * .37, size.width * .67, size.height * .22, size.width * .78, size.height * .40)
      ..cubicTo(size.width * .87, size.height * .56, size.width * .92, size.height * .55, size.width * 1.02, size.height * .42);
    canvas.drawPath(p, gold);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(size.width * .82, size.height * .29, 47, 35),
        const Radius.circular(10),
      ),
      gold,
    );
    canvas.drawLine(
      Offset(size.width * .85, size.height * .39),
      Offset(size.width * .88, size.height * .43),
      gold,
    );
    canvas.drawLine(
      Offset(size.width * .88, size.height * .43),
      Offset(size.width * .94, size.height * .34),
      gold,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _RequestTabs extends StatelessWidget {
  const _RequestTabs({required this.selectedIndex, required this.onSelected});
  final int selectedIndex;
  final ValueChanged<int> onSelected;

  @override
  Widget build(BuildContext context) {
    const labels = ['Все 3', 'В работе 1', 'Завершено 2'];
    return Container(
      height: 58,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: List.generate(labels.length, (index) {
          final selected = index == selectedIndex;
          return Expanded(
            child: InkWell(
              onTap: () => onSelected(index),
              borderRadius: BorderRadius.circular(15),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: selected ? AppColors.navy : Colors.transparent,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Text(
                  labels[index],
                  style: TextStyle(
                    color: selected ? Colors.white : AppColors.navy,
                    fontSize: 14,
                    fontWeight: selected ? FontWeight.w800 : FontWeight.w500,
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

class _ActiveRequestCard extends StatelessWidget {
  const _ActiveRequestCard({required this.hotel});
  final Hotel hotel;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0x88D4A535)),
        boxShadow: const [BoxShadow(color: Color(0x10031B4E), blurRadius: 18, offset: Offset(0, 8))],
      ),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: Image.asset(hotel.image, width: 130, height: 146, fit: BoxFit.cover),
              ),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      hotel.name,
                      maxLines: 2,
                      style: const TextStyle(
                        fontFamily: 'serif',
                        fontSize: 25,
                        height: 1.02,
                        color: AppColors.navy,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Icon(Icons.location_on_rounded, color: AppColors.gold, size: 22),
                        const SizedBox(width: 5),
                        Text(hotel.city, style: const TextStyle(color: AppColors.muted, fontSize: 14)),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF5DC),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.support_agent_rounded, color: AppColors.warning, size: 19),
                          SizedBox(width: 6),
                          Flexible(
                            child: Text(
                              'Оператор проверяет',
                              style: TextStyle(color: AppColors.warning, fontSize: 12.5, fontWeight: FontWeight.w600),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _InfoChip(icon: Icons.person_outline_rounded, text: '2 гостя'),
                        _InfoChip(icon: Icons.bed_outlined, text: 'Стандарт'),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 22),
          const _RequestProgress(),
          const SizedBox(height: 18),
          const Divider(height: 1),
          const SizedBox(height: 14),
          const Text(
            'Ожидаем ответ оператора',
            style: TextStyle(color: AppColors.muted, fontSize: 14),
          ),
          const SizedBox(height: 5),
          const Text(
            'Отправлено сегодня, 09:12',
            style: TextStyle(color: AppColors.muted, fontSize: 13),
          ),
        ],
      ),
    );
  }
}

class _InfoChip extends StatelessWidget {
  const _InfoChip({required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: AppColors.muted, size: 19),
          const SizedBox(width: 6),
          Text(text, style: const TextStyle(color: AppColors.muted, fontSize: 12.5)),
        ],
      ),
    );
  }
}

class _RequestProgress extends StatelessWidget {
  const _RequestProgress();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            const _ProgressNode(icon: Icons.check_rounded, state: 2),
            Expanded(child: Container(height: 2, color: AppColors.success)),
            const _ProgressNode(icon: null, state: 1),
            Expanded(child: Container(height: 2, color: AppColors.border)),
            const _ProgressNode(icon: null, state: 0),
          ],
        ),
        const SizedBox(height: 9),
        const Row(
          children: [
            Expanded(child: Text('Отправлен', textAlign: TextAlign.left, style: TextStyle(fontSize: 12, color: AppColors.navy))),
            Expanded(child: Text('Проверка', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: AppColors.navy))),
            Expanded(child: Text('Ответ', textAlign: TextAlign.right, style: TextStyle(fontSize: 12, color: AppColors.navy))),
          ],
        ),
      ],
    );
  }
}

class _ProgressNode extends StatelessWidget {
  const _ProgressNode({required this.icon, required this.state});
  final IconData? icon;
  final int state;

  @override
  Widget build(BuildContext context) {
    final color = state == 2 ? AppColors.success : (state == 1 ? AppColors.gold : AppColors.border);
    return Container(
      width: 38,
      height: 38,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        border: Border.all(color: color, width: state == 1 ? 3 : 2),
      ),
      child: icon == null
          ? Container(width: 20, height: 20, decoration: BoxDecoration(color: state == 1 ? AppColors.gold : Colors.white, shape: BoxShape.circle))
          : Icon(icon, color: color, size: 25),
    );
  }
}

class _CompletedRequestCard extends StatelessWidget {
  const _CompletedRequestCard({required this.hotel, required this.onOpen});
  final Hotel hotel;
  final VoidCallback onOpen;

  bool get available => hotel.name == 'Sport Hotel';

  @override
  Widget build(BuildContext context) {
    final color = available ? AppColors.success : AppColors.danger;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(21),
        border: Border.all(color: AppColors.border),
        boxShadow: const [BoxShadow(color: Color(0x0D031B4E), blurRadius: 14, offset: Offset(0, 6))],
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: Image.asset(hotel.image, width: 102, height: 102, fit: BoxFit.cover),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  hotel.name,
                  style: const TextStyle(
                    fontFamily: 'serif',
                    fontSize: 20,
                    color: AppColors.navy,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 4),
                Text('${hotel.city} · ${available ? '1 гость · Стандарт' : '2 гостя · Люкс'}', style: const TextStyle(color: AppColors.muted, fontSize: 12.5)),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
                  decoration: BoxDecoration(color: color.withOpacity(.10), borderRadius: BorderRadius.circular(12)),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(available ? Icons.check_circle_outline_rounded : Icons.remove_circle_outline_rounded, color: color, size: 19),
                      const SizedBox(width: 5),
                      Text(available ? 'Номер есть' : 'Свободных номеров нет', style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
                const SizedBox(height: 7),
                Text(available ? 'Ответ получен сегодня, 09:26' : 'Ответ получен вчера, 18:40', style: const TextStyle(color: AppColors.muted, fontSize: 11.5)),
              ],
            ),
          ),
          if (available)
            OutlinedButton(
              onPressed: onOpen,
              style: OutlinedButton.styleFrom(
                minimumSize: const Size(82, 42),
                padding: const EdgeInsets.symmetric(horizontal: 10),
              ),
              child: const Text('Открыть', style: TextStyle(fontSize: 11.5)),
            ),
        ],
      ),
    );
  }
}
