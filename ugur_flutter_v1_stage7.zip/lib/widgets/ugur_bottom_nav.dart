import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class UgurBottomNav extends StatelessWidget {
  const UgurBottomNav({
    super.key,
    required this.selectedIndex,
    required this.onSelected,
    required this.unreadCount,
  });

  final int selectedIndex;
  final ValueChanged<int> onSelected;
  final int unreadCount;

  static const _items = <_NavData>[
    _NavData(Icons.home_outlined, Icons.home_rounded, 'Главная'),
    _NavData(Icons.favorite_border_rounded, Icons.favorite_rounded, 'Избранное'),
    _NavData(Icons.receipt_long_outlined, Icons.receipt_long_rounded, 'Запросы'),
    _NavData(Icons.notifications_none_rounded, Icons.notifications_rounded, 'Уведомления'),
    _NavData(Icons.person_outline_rounded, Icons.person_rounded, 'Профиль'),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 6, 12, 10),
      padding: const EdgeInsets.fromLTRB(7, 10, 7, 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: const Color(0x0D061A45)),
        boxShadow: const [
          BoxShadow(color: Color(0x17061A45), blurRadius: 26, offset: Offset(0, 10)),
        ],
      ),
      child: Row(
        children: List.generate(_items.length, (index) {
          final item = _items[index];
          final active = index == selectedIndex;
          return Expanded(
            child: Semantics(
              button: true,
              selected: active,
              label: item.label,
              child: InkWell(
                onTap: () => onSelected(index),
                borderRadius: BorderRadius.circular(18),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 220),
                      curve: Curves.easeOutCubic,
                      width: 56,
                      height: 52,
                      decoration: BoxDecoration(
                        color: active ? AppColors.navy : const Color(0xFFF5F6FA),
                        borderRadius: BorderRadius.circular(17),
                      ),
                      child: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          Center(
                            child: Icon(
                              active ? item.selectedIcon : item.icon,
                              size: 28,
                              color: active ? AppColors.gold : AppColors.navy,
                            ),
                          ),
                          if (index == 3 && unreadCount > 0)
                            Positioned(
                              top: 5,
                              right: 6,
                              child: Container(
                                constraints: const BoxConstraints(minWidth: 18, minHeight: 18),
                                padding: const EdgeInsets.symmetric(horizontal: 5),
                                decoration: const BoxDecoration(
                                  color: AppColors.danger,
                                  shape: BoxShape.circle,
                                ),
                                alignment: Alignment.center,
                                child: Text(
                                  '$unreadCount',
                                  style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w800),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      item.label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: AppColors.navy,
                        fontSize: 10.5,
                        fontWeight: active ? FontWeight.w800 : FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 4),
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 220),
                      width: active ? 30 : 0,
                      height: 3,
                      decoration: BoxDecoration(
                        color: AppColors.gold,
                        borderRadius: BorderRadius.circular(99),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

class _NavData {
  const _NavData(this.icon, this.selectedIcon, this.label);
  final IconData icon;
  final IconData selectedIcon;
  final String label;
}
