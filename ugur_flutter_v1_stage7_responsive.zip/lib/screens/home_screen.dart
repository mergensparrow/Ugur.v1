import 'package:flutter/material.dart';
import '../data/app_state.dart';
import '../data/demo_data.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import '../widgets/mockup_image_slice.dart';
import 'city_picker_screen.dart';
import 'hotel_catalog_screen.dart';
import 'notifications_screen.dart';
import 'place_detail_screen.dart';

Widget _approvedPlacePhoto(String name) {
  final rect = switch (name) {
    'Монумент Нейтралитета' => const Rect.fromLTWH(31, 759, 167, 276),
    'Alem Center' => const Rect.fromLTWH(207, 759, 168, 276),
    'Арка Нейтралитета' => const Rect.fromLTWH(386, 759, 168, 276),
    'Парк Независимости' => const Rect.fromLTWH(563, 759, 148, 276),
    _ => null,
  };
  if (rect == null) {
    final place = touristPlacesByCity.values
        .expand((items) => items)
        .firstWhere((item) => item.name == name);
    return Image.asset(place.image, fit: BoxFit.cover);
  }
  return MockupImageSlice(
    asset: 'assets/images/mockup_home_main.jpeg',
    sourceSize: const Size(711, 1536),
    sourceRect: rect,
  );
}

Widget _approvedDestinationPhoto(String name, String fallbackAsset) {
  final rect = switch (name) {
    'Аваза' => const Rect.fromLTWH(50, 303, 754, 374),
    'Туркменбаши' => const Rect.fromLTWH(50, 808, 368, 210),
    'Дашогуз' => const Rect.fromLTWH(434, 808, 370, 210),
    _ => null,
  };
  if (rect == null) return Image.asset(fallbackAsset, fit: BoxFit.cover);
  return MockupImageSlice(
    asset: 'assets/images/mockup_home_lower.jpeg',
    sourceSize: const Size(853, 1844),
    sourceRect: rect,
  );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String selectedCity = 'Ашхабад';

  static const popularCities = <_CityCardData>[
    _CityCardData('Аваза', 'Курортная зона · 32 гостиницы', 'assets/images/city_avaza.jpg'),
    _CityCardData('Туркменбаши', 'Портовый город · 22 гостиницы', 'assets/images/city_turkmenbashi.jpg'),
    _CityCardData('Дашогуз', 'Исторический город · 16 гостиниц', 'assets/images/city_dashoguz.jpg'),
  ];

  static const otherCities = <_SmallCityData>[
    _SmallCityData('Балканабат', Color(0xFFFFF3DB), Color(0xFFD69B22)),
    _SmallCityData('Мары', Color(0xFFF1ECFF), Color(0xFF7753D2)),
    _SmallCityData('Туркменабад', Color(0xFFEAF7EE), Color(0xFF2F9C58)),
    _SmallCityData('Дашогуз', Color(0xFFEAF5FF), Color(0xFF2D8ECC)),
  ];

  List<TouristPlace> _orderedPlaces() {
    final result = List<TouristPlace>.from(placesForCity(selectedCity));
    if (selectedCity == 'Ашхабад') {
      const order = <String, int>{
        'Монумент Нейтралитета': 0,
        'Alem Center': 1,
        'Арка Нейтралитета': 2,
        'Парк Независимости': 3,
      };
      result.sort((a, b) => (order[a.name] ?? 99).compareTo(order[b.name] ?? 99));
    }
    return result;
  }

  Future<void> _pickCity() async {
    final value = await Navigator.of(context).push<String>(
      MaterialPageRoute(builder: (_) => CityPickerScreen(initialCity: selectedCity)),
    );
    if (value != null && mounted) setState(() => selectedCity = value);
  }

  void _openCatalog([String? city]) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => HotelCatalogScreen(city: city ?? selectedCity)),
    );
  }

  void _openNotifications() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const NotificationsScreen(showBackButton: true)),
    );
  }

  void _openPlace(TouristPlace place) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => PlaceDetailScreen(place: place)),
    );
  }

  void _showAllPlaces() {
    final places = _orderedPlaces();
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 0, 18, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                popularPlacesTitle(selectedCity),
                style: const TextStyle(
                  fontFamily: 'Lora',
                  fontSize: 24,
                  color: AppColors.navy,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 14),
              ...places.map(
                (place) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Material(
                    color: const Color(0xFFF9FAFD),
                    borderRadius: BorderRadius.circular(18),
                    child: ListTile(
                      onTap: () {
                        Navigator.pop(sheetContext);
                        _openPlace(place);
                      },
                      contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      leading: ClipRRect(
                        borderRadius: BorderRadius.circular(13),
                        child: Image.asset(place.image, width: 64, height: 64, fit: BoxFit.cover),
                      ),
                      title: Text(place.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                      subtitle: Text(place.category),
                      trailing: const Icon(Icons.chevron_right_rounded, color: AppColors.navy),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final places = _orderedPlaces();
    final compact = context.isCompactLayout;
    return SafeArea(
      child: Column(
        children: [
          Padding(
            padding: EdgeInsets.fromLTRB(compact ? 10 : 14, compact ? 13 : 14, compact ? 10 : 14, 0),
            child: _TopBrand(onNotifications: _openNotifications),
          ),
          SizedBox(height: compact ? 16 : 18),
          Expanded(
            child: ListView(
              padding: EdgeInsets.fromLTRB(compact ? 6 : 14, 0, compact ? 6 : 14, 22),
              children: [
                _CityDiscoveryPanel(
                  selectedCity: selectedCity,
                  places: places,
                  onPickCity: _pickCity,
                  onOpenPlace: _openPlace,
                  onShowAllPlaces: _showAllPlaces,
                  onSearchHotels: () => _openCatalog(),
                ),
                SizedBox(height: compact ? 14 : 18),
                _CountryDiscoveryPanel(
                  popularCities: popularCities,
                  otherCities: otherCities,
                  onOpenCity: _openCatalog,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}


class _UgurMark extends StatelessWidget {
  const _UgurMark({required this.size});
  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: const CustomPaint(painter: _UgurMarkPainter()),
    );
  }
}

class _UgurMarkPainter extends CustomPainter {
  const _UgurMarkPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppColors.gold
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * .15
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    final path = Path()
      ..moveTo(size.width * .22, size.height * .12)
      ..lineTo(size.width * .22, size.height * .62)
      ..cubicTo(
        size.width * .22,
        size.height * .84,
        size.width * .64,
        size.height * .84,
        size.width * .64,
        size.height * .62,
      )
      ..lineTo(size.width * .64, size.height * .24);
    canvas.drawPath(path, paint);
    canvas.drawCircle(
      Offset(size.width * .64, size.height * .12),
      size.width * .055,
      Paint()..color = AppColors.gold,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _TopBrand extends StatelessWidget {
  const _TopBrand({required this.onNotifications});
  final VoidCallback onNotifications;

  @override
  Widget build(BuildContext context) {
    final compact = context.isCompactLayout;
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: compact ? 3 : 7),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          _UgurMark(size: compact ? 40 : 48),
          SizedBox(width: compact ? 6 : 7),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'ugur',
                  style: TextStyle(
                    fontFamily: 'Lora',
                    fontSize: compact ? 30 : 34,
                    height: .9,
                    color: Colors.black,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                SizedBox(height: compact ? 4 : 7),
                Text(
                  'ГОСТИНИЦЫ ТУРКМЕНИСТАНА',
                  style: TextStyle(
                    fontSize: compact ? 8.5 : 9.5,
                    letterSpacing: .35,
                    color: AppColors.muted,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          AnimatedBuilder(
            animation: AppState.instance,
            builder: (_, __) {
              final unread = AppState.instance.unreadNotifications;
              return Stack(
                clipBehavior: Clip.none,
                children: [
                  Material(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    child: InkWell(
                      onTap: onNotifications,
                      borderRadius: BorderRadius.circular(16),
                      child: Container(
                        width: compact ? 46 : 54,
                        height: compact ? 46 : 54,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: AppColors.border),
                        ),
                        child: Icon(
                          Icons.notifications_none_rounded,
                          color: AppColors.navy,
                          size: compact ? 26 : 30,
                        ),
                      ),
                    ),
                  ),
                  if (unread > 0)
                    Positioned(
                      right: -4,
                      top: -5,
                      child: Container(
                        width: compact ? 19 : 23,
                        height: compact ? 19 : 23,
                        alignment: Alignment.center,
                        decoration: const BoxDecoration(color: AppColors.danger, shape: BoxShape.circle),
                        child: Text(
                          '$unread',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: compact ? 9 : 11,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}

class _CityDiscoveryPanel extends StatelessWidget {
  const _CityDiscoveryPanel({
    required this.selectedCity,
    required this.places,
    required this.onPickCity,
    required this.onOpenPlace,
    required this.onShowAllPlaces,
    required this.onSearchHotels,
  });

  final String selectedCity;
  final List<TouristPlace> places;
  final VoidCallback onPickCity;
  final ValueChanged<TouristPlace> onOpenPlace;
  final VoidCallback onShowAllPlaces;
  final VoidCallback onSearchHotels;

  @override
  Widget build(BuildContext context) {
    final compact = context.isCompactLayout;
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(29),
        border: Border.all(color: const Color(0x33CDA344)),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFFFFCF6), Color(0xFFF2F7FF)],
        ),
        boxShadow: const [
          BoxShadow(color: Color(0x15031B4E), blurRadius: 28, offset: Offset(0, 12)),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(29),
        child: Stack(
          children: [
            const Positioned.fill(
              child: IgnorePointer(child: CustomPaint(painter: _DiscoveryDecorationPainter())),
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(
                compact ? 19 : 20,
                compact ? 24 : 27,
                compact ? 19 : 20,
                compact ? 17 : 22,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Куда вы хотите\nпоехать?',
                    style: TextStyle(
                      fontSize: compact ? 29 : 36,
                      height: 1.02,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -.9,
                      color: AppColors.navy,
                    ),
                  ),
                  SizedBox(height: compact ? 12 : 15),
                  Text(
                    'Выберите город и посмотрите,\nчто интересного рядом',
                    style: TextStyle(
                      color: AppColors.muted,
                      fontSize: compact ? 13.2 : 14.5,
                      height: 1.42,
                    ),
                  ),
                  SizedBox(height: compact ? 27 : 34),
                  Material(
                    color: Colors.white,
                    elevation: 0,
                    borderRadius: BorderRadius.circular(24),
                    child: InkWell(
                      onTap: onPickCity,
                      borderRadius: BorderRadius.circular(24),
                      child: Container(
                        height: compact ? 70 : 86,
                        padding: EdgeInsets.symmetric(horizontal: compact ? 12 : 16),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(color: const Color(0x11031B4E)),
                          boxShadow: const [
                            BoxShadow(color: Color(0x10031B4E), blurRadius: 18, offset: Offset(0, 7)),
                          ],
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: compact ? 44 : 54,
                              height: compact ? 44 : 54,
                              decoration: const BoxDecoration(
                                color: Color(0xFFFFF0C9),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                Icons.location_on_rounded,
                                color: AppColors.gold,
                                size: compact ? 29 : 34,
                              ),
                            ),
                            SizedBox(width: compact ? 11 : 14),
                            Expanded(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Выберите город',
                                    style: TextStyle(
                                      color: const Color(0xFFB48726),
                                      fontSize: compact ? 11.3 : 13,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                  SizedBox(height: compact ? 2 : 4),
                                  SizedBox(
                                    width: double.infinity,
                                    height: compact ? 22 : 28,
                                    child: FittedBox(
                                      fit: BoxFit.scaleDown,
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        selectedCity,
                                        maxLines: 1,
                                        style: TextStyle(
                                          fontSize: compact ? 23 : 27,
                                          height: 1,
                                          color: AppColors.navy,
                                          fontWeight: FontWeight.w800,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Icon(
                              Icons.keyboard_arrow_down_rounded,
                              size: compact ? 25 : 31,
                              color: AppColors.navy,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: compact ? 34 : 44),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Expanded(
                        child: Text(
                          popularPlacesTitle(selectedCity),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontFamily: 'Lora',
                            fontSize: compact ? 14.2 : 20,
                            height: 1.05,
                            color: AppColors.navy,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                      TextButton(
                        onPressed: onShowAllPlaces,
                        style: TextButton.styleFrom(
                          foregroundColor: const Color(0xFFB18426),
                          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
                        ),
                        child: Text(
                          'Смотреть все',
                          style: TextStyle(fontSize: compact ? 10.2 : 12.5),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: compact ? 10 : 12),
                  SizedBox(
                    height: compact ? 178 : 205,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: places.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 10),
                      itemBuilder: (_, index) => _PlaceCard(
                        place: places[index],
                        highlighted: places[index].name == 'Alem Center',
                        onTap: () => onOpenPlace(places[index]),
                      ),
                    ),
                  ),
                  SizedBox(height: compact ? 12 : 17),
                  Center(
                    child: Container(
                      width: 124,
                      height: 3,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(99),
                        gradient: const LinearGradient(
                          colors: [AppColors.gold, AppColors.gold, Color(0xFFD8E5F5), Color(0xFFB8CCE6)],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: compact ? 14 : 19),
                  FilledButton.icon(
                    onPressed: onSearchHotels,
                    icon: Icon(Icons.search_rounded, size: compact ? 24 : 27),
                    label: Text(
                      'Найти гостиницы',
                      style: TextStyle(fontSize: compact ? 15.5 : 17),
                    ),
                    style: FilledButton.styleFrom(
                      minimumSize: Size.fromHeight(compact ? 56 : 60),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DiscoveryDecorationPainter extends CustomPainter {
  const _DiscoveryDecorationPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final hairline = Paint()
      ..color = const Color(0x1F7896B8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = .9;

    for (var i = 0; i < 16; i++) {
      final x = size.width * (.48 + (i % 8) * .067);
      final row = i ~/ 8;
      final baseY = size.height * (.25 + row * .035);
      final h = 35.0 + (i % 4) * 15;
      canvas.drawRect(Rect.fromLTWH(x, baseY - h, 18, h), hairline);
      canvas.drawLine(Offset(x + 9, baseY - h), Offset(x + 9, baseY - h - 24), hairline);
      if (i % 2 == 0) {
        canvas.drawCircle(Offset(x + 9, baseY - h - 5), 5, hairline);
      }
    }

    final route = Paint()
      ..color = const Color(0xC7C59533)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.45;
    final path = Path()
      ..moveTo(size.width * .47, size.height * .13)
      ..cubicTo(size.width * .72, size.height * .14, size.width * .55, size.height * .27, size.width * .17, size.height * .31)
      ..cubicTo(size.width * -.02, size.height * .34, size.width * .02, size.height * .46, size.width * .78, size.height * .50)
      ..cubicTo(size.width * .91, size.height * .51, size.width * .82, size.height * .55, size.width * .74, size.height * .57);
    canvas.drawPath(path, route);

    final dot = Paint()..color = const Color(0xFFC59635);
    final whiteDot = Paint()..color = Colors.white;
    for (final point in [
      Offset(size.width * .47, size.height * .13),
      Offset(size.width * .17, size.height * .31),
      Offset(size.width * .74, size.height * .57),
    ]) {
      canvas.drawCircle(point, 5.1, dot);
      canvas.drawCircle(point, 2.0, whiteDot);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _PlaceCard extends StatelessWidget {
  const _PlaceCard({required this.place, required this.onTap, required this.highlighted});

  final TouristPlace place;
  final VoidCallback onTap;
  final bool highlighted;

  @override
  Widget build(BuildContext context) {
    final compact = context.isCompactLayout;
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(17),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(17),
        child: Container(
          width: compact ? 86 : 142,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(17),
            border: Border.all(
              color: highlighted ? AppColors.gold : AppColors.border,
              width: highlighted ? 2 : 1,
            ),
            boxShadow: const [
              BoxShadow(color: Color(0x11031B4E), blurRadius: 13, offset: Offset(0, 5)),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(15),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(child: _approvedPlacePhoto(place.name)),
                Container(
                  height: compact ? 40 : 58,
                  padding: EdgeInsets.fromLTRB(compact ? 7 : 11, 5, 6, 4),
                  color: Colors.white,
                  child: Text(
                    place.name,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: AppColors.navy,
                      fontSize: compact ? 10.4 : 13.5,
                      height: 1.12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _CountryDiscoveryPanel extends StatelessWidget {
  const _CountryDiscoveryPanel({
    required this.popularCities,
    required this.otherCities,
    required this.onOpenCity,
  });

  final List<_CityCardData> popularCities;
  final List<_SmallCityData> otherCities;
  final ValueChanged<String> onOpenCity;

  void _showAllDestinations(BuildContext context) {
    final combined = <_CityCardData>[...popularCities];
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 0, 18, 22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Популярные направления',
                style: TextStyle(
                  fontFamily: 'Lora',
                  fontSize: 24,
                  color: AppColors.navy,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 12),
              ...combined.map(
                (city) => ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.asset(city.asset, width: 58, height: 58, fit: BoxFit.cover),
                  ),
                  title: Text(city.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text(city.subtitle),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () {
                    Navigator.pop(sheetContext);
                    onOpenCity(city.name);
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final compact = context.isCompactLayout;
    return Container(
      padding: EdgeInsets.fromLTRB(
        compact ? 13 : 17,
        compact ? 18 : 23,
        compact ? 13 : 17,
        compact ? 16 : 21,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(29),
        border: Border.all(color: AppColors.border),
        boxShadow: const [BoxShadow(color: Color(0x12031B4E), blurRadius: 24, offset: Offset(0, 9))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'Популярные направления',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: 'Lora',
                    fontSize: compact ? 16 : 22,
                    color: AppColors.navy,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              TextButton(
                onPressed: () => _showAllDestinations(context),
                style: TextButton.styleFrom(foregroundColor: const Color(0xFFB18426)),
                child: Text('Смотреть все', style: TextStyle(fontSize: compact ? 10.5 : 14)),
              ),
            ],
          ),
          SizedBox(height: compact ? 7 : 12),
          _FeaturedDestinationCard(
            data: popularCities.first,
            onTap: () => onOpenCity(popularCities.first.name),
          ),
          SizedBox(height: compact ? 8 : 12),
          Row(
            children: [
              Expanded(
                child: _SmallDestinationCard(
                  data: popularCities[1],
                  onTap: () => onOpenCity(popularCities[1].name),
                ),
              ),
              SizedBox(width: compact ? 8 : 12),
              Expanded(
                child: _SmallDestinationCard(
                  data: popularCities[2],
                  onTap: () => onOpenCity(popularCities[2].name),
                ),
              ),
            ],
          ),
          SizedBox(height: compact ? 11 : 18),
          const Center(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _CarouselDot(active: true),
                SizedBox(width: 10),
                _CarouselDot(active: false),
                SizedBox(width: 10),
                _CarouselDot(active: false),
              ],
            ),
          ),
          SizedBox(height: compact ? 14 : 25),
          Text(
            'Другие города',
            style: TextStyle(
              fontFamily: 'Lora',
              fontSize: compact ? 18 : 22,
              color: AppColors.navy,
              fontWeight: FontWeight.w800,
            ),
          ),
          SizedBox(height: compact ? 9 : 16),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: otherCities.length,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: compact ? 8 : 12,
              mainAxisSpacing: compact ? 8 : 12,
              mainAxisExtent: compact ? 60 : 82,
            ),
            itemBuilder: (_, index) => _OtherCityTile(
              data: otherCities[index],
              onTap: () => onOpenCity(otherCities[index].name),
            ),
          ),
        ],
      ),
    );
  }
}

class _FeaturedDestinationCard extends StatelessWidget {
  const _FeaturedDestinationCard({required this.data, required this.onTap});
  final _CityCardData data;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final compact = context.isCompactLayout;
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(21),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(21),
        child: Container(
          height: compact ? 234 : 278,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(21),
            border: Border.all(color: AppColors.border),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      _approvedDestinationPhoto(data.name, data.asset),
                      Positioned(
                        top: 14,
                        right: 14,
                        child: Container(
                          width: compact ? 38 : 48,
                          height: compact ? 38 : 48,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(15),
                            boxShadow: const [BoxShadow(color: Color(0x19031B4E), blurRadius: 12)],
                          ),
                          child: Icon(
                            Icons.bookmark_border_rounded,
                            color: AppColors.navy,
                            size: compact ? 21 : 27,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  height: compact ? 61 : 76,
                  padding: EdgeInsets.fromLTRB(compact ? 12 : 17, 7, compact ? 12 : 17, 7),
                  color: Colors.white,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        data.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontFamily: 'Lora',
                          fontSize: compact ? 18 : 23,
                          color: AppColors.navy,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        data.subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: AppColors.muted, fontSize: compact ? 11 : 13.5),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SmallDestinationCard extends StatelessWidget {
  const _SmallDestinationCard({required this.data, required this.onTap});
  final _CityCardData data;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final compact = context.isCompactLayout;
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          height: compact ? 149 : 176,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: AppColors.border),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(19),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(child: _approvedDestinationPhoto(data.name, data.asset)),
                Container(
                  height: compact ? 46 : 58,
                  padding: EdgeInsets.fromLTRB(compact ? 8 : 12, 5, 7, 5),
                  color: Colors.white,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        data.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: compact ? 12.5 : 15.5,
                          color: AppColors.navy,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        data.subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: compact ? 8.8 : 10.5, color: AppColors.muted),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _OtherCityTile extends StatelessWidget {
  const _OtherCityTile({required this.data, required this.onTap});
  final _SmallCityData data;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final narrowTile = constraints.maxWidth < 160;
        return Material(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(18),
            child: Container(
              padding: EdgeInsets.symmetric(
                horizontal: narrowTile ? 7 : 12,
                vertical: narrowTile ? 7 : 10,
              ),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  Container(
                    width: narrowTile ? 36 : 48,
                    height: narrowTile ? 36 : 48,
                    decoration: BoxDecoration(
                      color: data.iconBackground,
                      borderRadius: BorderRadius.circular(narrowTile ? 11 : 14),
                    ),
                    child: Icon(
                      Icons.account_balance_rounded,
                      color: data.iconColor,
                      size: narrowTile ? 20 : 25,
                    ),
                  ),
                  SizedBox(width: narrowTile ? 7 : 10),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: double.infinity,
                          child: FittedBox(
                            fit: BoxFit.scaleDown,
                            alignment: Alignment.centerLeft,
                            child: Text(
                              data.name,
                              maxLines: 1,
                              style: TextStyle(
                                fontSize: narrowTile ? 11.5 : 13.5,
                                color: AppColors.navy,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: narrowTile ? 2 : 4),
                        SizedBox(
                          width: double.infinity,
                          child: FittedBox(
                            fit: BoxFit.scaleDown,
                            alignment: Alignment.centerLeft,
                            child: Text(
                              '${cityHotelCounts[data.name] ?? 0} гостиниц',
                              maxLines: 1,
                              style: TextStyle(
                                fontSize: narrowTile ? 10 : 11.5,
                                color: AppColors.muted,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Icon(
                    Icons.chevron_right_rounded,
                    color: AppColors.navy,
                    size: narrowTile ? 19 : 24,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _CarouselDot extends StatelessWidget {
  const _CarouselDot({required this.active});
  final bool active;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: active ? 12 : 9,
      height: active ? 12 : 9,
      decoration: BoxDecoration(
        color: active ? AppColors.gold : const Color(0xFFDDE1EA),
        shape: BoxShape.circle,
      ),
    );
  }
}

class _CityCardData {
  const _CityCardData(this.name, this.subtitle, this.asset);
  final String name;
  final String subtitle;
  final String asset;
}

class _SmallCityData {
  const _SmallCityData(this.name, this.iconBackground, this.iconColor);
  final String name;
  final Color iconBackground;
  final Color iconColor;
}
