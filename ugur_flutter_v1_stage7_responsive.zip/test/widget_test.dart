import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ugur/main.dart';
import 'package:ugur/screens/main_shell.dart';
import 'package:ugur/theme/app_theme.dart';

void main() {
  testWidgets('welcome screen renders', (tester) async {
    await tester.pumpWidget(const UgurApp());
    expect(find.text('Начать'), findsOneWidget);
  });

  for (final width in <double>[320, 360]) {
    testWidgets('main shell has no layout exception at ${width.toInt()} px', (tester) async {
      tester.view.devicePixelRatio = 1;
      tester.view.physicalSize = Size(width, 720);
      addTearDown(() {
        tester.view.resetDevicePixelRatio();
        tester.view.resetPhysicalSize();
      });

      await tester.pumpWidget(
        MaterialApp(
          theme: AppTheme.light,
          home: const MainShell(),
        ),
      );
      await tester.pump();

      expect(tester.takeException(), isNull);
      expect(find.text('Уведомления'), findsWidgets);
    });
  }
}
