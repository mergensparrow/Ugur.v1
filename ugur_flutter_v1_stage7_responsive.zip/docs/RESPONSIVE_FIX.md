# Responsive layout fix

This revision keeps the Stage 7 visual system and adds compact phone-layout
rules for Android devices that expose up to 599 logical pixels to Flutter.

## Updated areas

- Home discovery panels and destination cards use compact spacing on every
  ordinary phone width; the large branch now starts at 600 px for tablets.
- The featured destination caption has bounded single-line text, preventing the
  previous 1 px vertical overflow.
- The two-column “Другие города” grid uses a fixed safe row extent and compact
  icon/text geometry, preventing the previous 18 px overflow.
- Bottom navigation scales its icon tiles and labels; long labels remain fully
  visible instead of being ellipsized.
- Favorites, requests, notifications, and profile use the same compact width
  breakpoint so their scale stays consistent with the approved mock-ups.
- Widget regression coverage now includes 320, 360, 411, and 480 px
  main-shell widths.

## Verification

Run on a machine with Flutter installed:

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --debug
```

The included GitHub Actions workflow runs the same analyzer, test, and APK
build sequence.
