enum AvailabilityStatus { available, unavailable, recheck, checking }

extension AvailabilityStatusX on AvailabilityStatus {
  String get label => switch (this) {
    AvailabilityStatus.available => 'Номера есть',
    AvailabilityStatus.unavailable => 'Мест нет',
    AvailabilityStatus.recheck => 'Нужно перепроверить',
    AvailabilityStatus.checking => 'Проверяем сейчас',
  };
}

class RoomPrice {
  const RoomPrice(this.name, this.capacity, this.price, {this.tag});
  final String name;
  final String capacity;
  final int price;
  final String? tag;
}

class Hotel {
  const Hotel({
    required this.name,
    required this.city,
    required this.rating,
    required this.reviews,
    required this.price,
    required this.status,
    required this.image,
    required this.description,
    required this.rooms,
  });
  final String name;
  final String city;
  final double rating;
  final int reviews;
  final int price;
  final AvailabilityStatus status;
  final String image;
  final String description;
  final List<RoomPrice> rooms;
}
