import '../models/models.dart';

const cityNames = [
  'Ашхабад',
  'Аваза',
  'Туркменбаши',
  'Балканабат',
  'Дашогуз',
  'Туркменабад',
  'Мары',
  'Куняургенч',
  'Гызыларбат',
];

const hotels = [
  Hotel(
    name: 'Yyldyz Hotel',
    city: 'Ашхабад',
    rating: 4.8,
    reviews: 86,
    price: 850,
    status: AvailabilityStatus.available,
    image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=88',
    description: 'Премиальная гостиница с панорамным видом, ресторанами и современными удобствами.',
    rooms: [
      RoomPrice('Стандарт', '1 человек', 650),
      RoomPrice('Стандарт', '2 человека', 850, tag: 'Популярный выбор'),
      RoomPrice('Полулюкс', '2 человека', 1200),
      RoomPrice('Люкс', '2 человека', 1800),
      RoomPrice('Семейный', '4 человека', 2500, tag: 'Для семьи'),
    ],
  ),
  Hotel(
    name: 'Sport Hotel',
    city: 'Ашхабад',
    rating: 4.5,
    reviews: 42,
    price: 650,
    status: AvailabilityStatus.recheck,
    image: 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?auto=format&fit=crop&w=1200&q=88',
    description: 'Практичная гостиница рядом со спортивной инфраструктурой.',
    rooms: [
      RoomPrice('Стандарт', '1 человек', 650),
      RoomPrice('Полулюкс', '2 человека', 950),
    ],
  ),
  Hotel(
    name: 'Arçabil Hotel',
    city: 'Ашхабад',
    rating: 4.7,
    reviews: 64,
    price: 720,
    status: AvailabilityStatus.unavailable,
    image: 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=88',
    description: 'Современная городская гостиница с просторными номерами.',
    rooms: [
      RoomPrice('Стандарт', '1 человек', 720),
      RoomPrice('Люкс', '2 человека', 1650),
    ],
  ),
];
