import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'personal_profile_screen.dart';
import 'welcome_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    Widget item(IconData icon, String title, VoidCallback onTap, {bool danger = false}) => ListTile(
      onTap: onTap,
      leading: Icon(icon, color: danger ? AppColors.danger : AppColors.navy),
      title: Text(title, style: TextStyle(fontWeight: FontWeight.w800, color: danger ? AppColors.danger : null)),
      trailing: const Icon(Icons.chevron_right),
    );

    return SafeArea(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          Container(
            color: AppColors.navy,
            padding: const EdgeInsets.all(22),
            child: const Row(children: [
              CircleAvatar(radius: 36, child: Icon(Icons.person, size: 38)),
              SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Мерген', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w900)),
                Text('+993 •• •• ••', style: TextStyle(color: Colors.white70)),
                Text('mergen@example.com', style: TextStyle(color: Colors.white70)),
              ])),
              Icon(Icons.settings_outlined, color: Colors.white),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Card(
              child: Column(children: [
                item(Icons.person_outline, 'Личный профиль', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PersonalProfileScreen()))),
                item(Icons.language, 'Язык', () {}),
                item(Icons.notifications_none, 'Уведомления', () {}),
                item(Icons.support_agent, 'Поддержка', () {}),
                item(Icons.privacy_tip_outlined, 'Конфиденциальность', () {}),
                item(Icons.logout, 'Выйти из аккаунта', () => Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const WelcomeScreen()), (_) => false), danger: true),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}
