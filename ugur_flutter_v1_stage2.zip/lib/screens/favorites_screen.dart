import 'package:flutter/material.dart';
import '../data/demo_data.dart';
import '../theme/app_theme.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Избранное', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
          Text('${hotels.length} гостиницы', style: const TextStyle(color: AppColors.muted)),
          const SizedBox(height: 18),
          ...hotels.map((h) => Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Card(
              child: ListTile(
                leading: CircleAvatar(backgroundImage: NetworkImage(h.image)),
                title: Text(h.name, style: const TextStyle(fontWeight: FontWeight.w900)),
                subtitle: Text('${h.city} · от ${h.price} TMT\n${h.status.label}'),
                isThreeLine: true,
                trailing: const Icon(Icons.favorite_rounded, color: AppColors.danger),
              ),
            ),
          )),
        ],
      ),
    );
  }
}
