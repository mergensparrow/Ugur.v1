import 'package:flutter/material.dart';
import '../data/demo_data.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import 'hotel_detail_screen.dart';

class HotelCatalogScreen extends StatelessWidget {
  const HotelCatalogScreen({super.key, required this.city});
  final String city;

  @override
  Widget build(BuildContext context) {
    final list = hotels.where((h) => h.city == city).toList();
    return Scaffold(
      appBar: AppBar(
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(city, style: const TextStyle(fontWeight: FontWeight.w900)),
          Text('${list.length} гостиницы', style: const TextStyle(fontSize: 12, color: AppColors.muted)),
        ]),
        actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.map_outlined)), IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none_rounded))],
      ),
      body: Column(
        children: [
          SizedBox(
            height: 52,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 14),
              children: const [
                Padding(padding: EdgeInsets.only(right: 8), child: Chip(label: Text('Цена'))),
                Padding(padding: EdgeInsets.only(right: 8), child: Chip(label: Text('Рейтинг'))),
                Padding(padding: EdgeInsets.only(right: 8), child: Chip(label: Text('Наличие'))),
                Chip(label: Text('Фильтры')),
              ],
            ),
          ),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: list.length,
              separatorBuilder: (_, __) => const SizedBox(height: 16),
              itemBuilder: (_, i) => _HotelCard(
                hotel: list[i],
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => HotelDetailScreen(hotel: list[i]))),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _HotelCard extends StatelessWidget {
  const _HotelCard({required this.hotel, required this.onTap});
  final Hotel hotel;
  final VoidCallback onTap;

  Color get statusColor => switch (hotel.status) {
    AvailabilityStatus.available => AppColors.success,
    AvailabilityStatus.unavailable => AppColors.danger,
    AvailabilityStatus.recheck => AppColors.warning,
    AvailabilityStatus.checking => AppColors.gold,
  };

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Stack(children: [
            Image.network(hotel.image, height: 215, width: double.infinity, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(height: 215, color: const Color(0xFFE7E9ED))),
            const Positioned(top: 12, right: 12, child: CircleAvatar(backgroundColor: Colors.white, child: Icon(Icons.favorite_border_rounded))),
          ]),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(hotel.name, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
              Text(hotel.city, style: const TextStyle(color: AppColors.muted)),
              const SizedBox(height: 12),
              Row(children: [
                const Icon(Icons.star_rounded, color: AppColors.gold, size: 20),
                Text(' ${hotel.rating}', style: const TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(width: 14),
                const Icon(Icons.chat_bubble_outline_rounded, size: 19),
                Text(' ${hotel.reviews} отзывов'),
              ]),
              const SizedBox(height: 12),
              Row(children: [
                CircleAvatar(radius: 4, backgroundColor: statusColor),
                const SizedBox(width: 7),
                Expanded(child: Text(hotel.status.label, style: TextStyle(color: statusColor, fontWeight: FontWeight.w800))),
                Text('от ${hotel.price} TMT', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              ]),
            ]),
          ),
        ]),
      ),
    );
  }
}
