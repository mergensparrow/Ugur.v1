import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});
  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  bool onlyNew = false;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(children: [
            const Expanded(child: Text('Уведомления', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900))),
            TextButton.icon(onPressed: () {}, icon: const Icon(Icons.delete_outline), label: const Text('Очистить')),
          ]),
          SegmentedButton<bool>(
            segments: const [ButtonSegment(value: false, label: Text('Все')), ButtonSegment(value: true, label: Text('Новые'))],
            selected: {onlyNew},
            onSelectionChanged: (v) => setState(() => onlyNew = v.first),
          ),
          const SizedBox(height: 18),
          const Card(child: ListTile(leading: Icon(Icons.check_circle, color: AppColors.success), title: Text('Есть свободные номера'), subtitle: Text('Yyldyz Hotel подтвердил наличие.'))),
          const SizedBox(height: 12),
          const Card(child: ListTile(leading: Icon(Icons.schedule, color: AppColors.warning), title: Text('Нужно перепроверить'), subtitle: Text('Оператор продолжает уточнение.'))),
          const SizedBox(height: 12),
          const Card(child: ListTile(leading: Icon(Icons.send, color: AppColors.gold), title: Text('Запрос отправлен'), subtitle: Text('Запрос передан оператору Ugur.'))),
        ],
      ),
    );
  }
}
