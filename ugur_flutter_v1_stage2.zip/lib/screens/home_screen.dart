import 'package:flutter/material.dart';
import '../data/demo_data.dart';
import '../theme/app_theme.dart';
import 'city_picker_screen.dart';
import 'hotel_catalog_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String selectedCity = 'Ашхабад';

  Future<void> _pick() async {
    final value = await Navigator.of(context).push<String>(
      MaterialPageRoute(builder: (_) => CityPickerScreen(initialCity: selectedCity)),
    );
    if (value != null) setState(() => selectedCity = value);
  }

  void _open([String? city]) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => HotelCatalogScreen(city: city ?? selectedCity)));
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 28),
        children: [
          Row(
            children: [
              const Icon(Icons.route_rounded, color: AppColors.gold, size: 36),
              const SizedBox(width: 8),
              const Text('ugur', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900)),
              const Spacer(),
              Badge(label: const Text('2'), child: IconButton.filledTonal(onPressed: () {}, icon: const Icon(Icons.notifications_none_rounded))),
            ],
          ),
          const SizedBox(height: 26),
          const Text('Куда вы хотите поехать?', style: TextStyle(fontSize: 31, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          const Text('Выберите город, чтобы найти подходящую гостиницу.', style: TextStyle(color: AppColors.muted)),
          const SizedBox(height: 20),
          ListTile(
            onTap: _pick,
            tileColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
            leading: const Icon(Icons.location_on_outlined, color: AppColors.gold),
            title: Text(selectedCity, style: const TextStyle(fontWeight: FontWeight.w900)),
            trailing: const Icon(Icons.keyboard_arrow_down_rounded),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: _open, icon: const Icon(Icons.search_rounded), label: const Text('Найти гостиницы')),
          const SizedBox(height: 28),
          const Text('Города Туркменистана', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
          const SizedBox(height: 14),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: 7,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: .9),
            itemBuilder: (_, index) {
              final city = cityNames[index];
              return GestureDetector(
                onTap: () => _open(city),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(24),
                    gradient: LinearGradient(colors: [AppColors.navy, AppColors.navy.withOpacity(.72)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                  ),
                  padding: const EdgeInsets.all(15),
                  alignment: Alignment.bottomLeft,
                  child: Text(city, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
                ),
              );
            },
          ),
          const SizedBox(height: 24),
          const Text('Другие города', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            children: cityNames.skip(7).map((e) => ActionChip(label: Text(e), onPressed: () => _open(e))).toList(),
          ),
        ],
      ),
    );
  }
}
