import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class PersonalProfileScreen extends StatelessWidget {
  const PersonalProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    Widget row(String label, String value) => Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        title: Text(label, style: const TextStyle(color: AppColors.muted, fontSize: 12)),
        subtitle: Text(value, style: const TextStyle(color: AppColors.text, fontSize: 16, fontWeight: FontWeight.w800)),
      ),
    );

    return Scaffold(
      appBar: AppBar(title: const Text('Личный профиль')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Center(child: CircleAvatar(radius: 52, backgroundColor: AppColors.navy, child: Icon(Icons.person, color: Colors.white, size: 54))),
          const SizedBox(height: 24),
          row('Имя', 'Мерген'),
          row('Телефон', '+993 •• •• ••'),
          row('Email', 'mergen@example.com'),
          row('Любимые города', 'Ашхабад, Туркменбаши'),
          row('Предпочитаемая цена', '500–900 TMT'),
          const SizedBox(height: 20),
          FilledButton.icon(onPressed: () {}, icon: const Icon(Icons.edit_outlined), label: const Text('Изменить данные')),
          const SizedBox(height: 10),
          OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.delete_outline), label: const Text('Удалить аккаунт'), style: OutlinedButton.styleFrom(foregroundColor: AppColors.danger)),
        ],
      ),
    );
  }
}
