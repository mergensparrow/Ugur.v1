import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'main_shell.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  void _open(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => const _LoginSheet(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.network(
            'https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?auto=format&fit=crop&w=1400&q=90',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(color: AppColors.navy),
          ),
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0x66000000), Color(0x22000000), Color(0xEE071A2B)],
              ),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(24, 34, 24, 28),
              child: Column(
                children: [
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.route_rounded, color: AppColors.gold, size: 44),
                      SizedBox(width: 9),
                      Text('ugur', style: TextStyle(color: Colors.white, fontSize: 40, fontWeight: FontWeight.w900)),
                    ],
                  ),
                  const Spacer(),
                  const Text(
                    'Путешествие\nначинается здесь',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white, fontSize: 40, height: 1.05, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 18),
                  const Text(
                    'Все гостиницы Туркменистана\nв одном приложении',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white70, fontSize: 17, height: 1.35),
                  ),
                  const SizedBox(height: 32),
                  FilledButton(
                    onPressed: () => _open(context),
                    style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: AppColors.navy),
                    child: const Text('Начать'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _LoginSheet extends StatelessWidget {
  const _LoginSheet();

  void _enter(BuildContext context) {
    Navigator.of(context).pop();
    Navigator.of(context).pushReplacement(
      PageRouteBuilder<void>(
        pageBuilder: (_, animation, __) => FadeTransition(opacity: animation, child: const MainShell()),
        transitionDuration: const Duration(milliseconds: 420),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Widget item(IconData icon, String title, String subtitle) => ListTile(
      onTap: () => _enter(context),
      leading: CircleAvatar(backgroundColor: const Color(0xFFF1F3F6), child: Icon(icon, color: AppColors.navy)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
      subtitle: Text(subtitle),
      trailing: const Icon(Icons.chevron_right_rounded),
    );

    return Container(
      padding: EdgeInsets.fromLTRB(18, 12, 18, 20 + MediaQuery.paddingOf(context).bottom),
      decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(32))),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(width: 44, height: 5, decoration: BoxDecoration(color: const Color(0xFFD5D7DB), borderRadius: BorderRadius.circular(99))),
          const SizedBox(height: 12),
          item(Icons.login_rounded, 'Войти', 'У меня есть аккаунт'),
          item(Icons.person_add_alt_1_rounded, 'Создать аккаунт', 'Новый пользователь'),
          item(Icons.visibility_outlined, 'Продолжить как гость', 'Без регистрации'),
          const SizedBox(height: 10),
          const Text(
            'Продолжая, вы соглашаетесь с условиями использования и политикой конфиденциальности.',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppColors.muted, fontSize: 11, height: 1.4),
          ),
        ],
      ),
    );
  }
}
