import 'package:flutter/material.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import 'room_prices_screen.dart';
import 'availability_request_screen.dart';

class HotelDetailScreen extends StatelessWidget {
  const HotelDetailScreen({super.key, required this.hotel});
  final Hotel hotel;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: true,
            expandedHeight: 330,
            actions: [IconButton.filledTonal(onPressed: () {}, icon: const Icon(Icons.share_outlined)), IconButton.filledTonal(onPressed: () {}, icon: const Icon(Icons.favorite_border_rounded))],
            flexibleSpace: FlexibleSpaceBar(background: Image.network(hotel.image, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: const Color(0xFFE7E9ED)))),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 20, 18, 30),
            sliver: SliverList.list(children: [
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(hotel.name, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
                  Text(hotel.city, style: const TextStyle(color: AppColors.muted)),
                ])),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text('★ ${hotel.rating}', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: AppColors.gold)),
                  Text('${hotel.reviews} отзывов', style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                ]),
              ]),
              const SizedBox(height: 16),
              Wrap(spacing: 8, children: const [Chip(label: Text('Wi‑Fi')), Chip(label: Text('Парковка')), Chip(label: Text('Бассейн')), Chip(label: Text('Ресторан'))]),
              const SizedBox(height: 18),
              Text('от ${hotel.price} TMT / ночь', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
              const SizedBox(height: 18),
              FilledButton.icon(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => RoomPricesScreen(hotel: hotel))),
                icon: const Icon(Icons.payments_outlined),
                label: const Text('Цены на номера'),
                style: FilledButton.styleFrom(backgroundColor: AppColors.gold),
              ),
              const SizedBox(height: 10),
              FilledButton.icon(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AvailabilityRequestScreen(hotel: hotel))),
                icon: const Icon(Icons.search_rounded),
                label: const Text('Проверить наличие'),
              ),
              const SizedBox(height: 10),
              FilledButton.icon(onPressed: null, icon: const Icon(Icons.lock_clock_outlined), label: const Text('Онлайн-бронирование · Скоро в Ugur')),
              const SizedBox(height: 28),
              const Text('Об отеле', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 10),
              Text(hotel.description, style: const TextStyle(fontSize: 15, height: 1.55)),
              const SizedBox(height: 28),
              const Text('Отзывы гостей', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 12),
              const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Аман М.  ★★★★★\nОтличный отель! Номер чистый, персонал вежливый, вид потрясающий.'))),
            ]),
          ),
        ],
      ),
    );
  }
}
