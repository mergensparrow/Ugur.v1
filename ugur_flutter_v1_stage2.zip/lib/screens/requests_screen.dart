import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class RequestsScreen extends StatelessWidget {
  const RequestsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          Text('Запросы', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
          Text('История проверок наличия', style: TextStyle(color: AppColors.muted)),
          SizedBox(height: 18),
          Card(child: ListTile(title: Text('Yyldyz Hotel'), subtitle: Text('Оператор проверяет · 2 гостя · Стандарт'))),
          SizedBox(height: 12),
          Card(child: ListTile(title: Text('Sport Hotel'), subtitle: Text('Номер есть · 1 гость · Стандарт'))),
        ],
      ),
    );
  }
}
