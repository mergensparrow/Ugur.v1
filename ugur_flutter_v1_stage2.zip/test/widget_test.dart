import 'package:flutter_test/flutter_test.dart';
import 'package:ugur/main.dart';

void main() {
  testWidgets('welcome screen renders', (tester) async {
    await tester.pumpWidget(const UgurApp());
    expect(find.text('Начать'), findsOneWidget);
  });
}
